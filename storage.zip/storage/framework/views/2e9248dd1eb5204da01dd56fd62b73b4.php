<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Rekap Pembayaran</title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 11px;
        }

        h3 {
            margin-bottom: 4px;
        }

        p {
            margin: 2px 0 10px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 8px;
        }

        th, td {
            border: 1px solid #333;
            padding: 6px;
            vertical-align: middle;
        }

        th {
            background: #f0f0f0;
            text-align: center;
        }

        td {
            text-align: left;
        }

        .text-center {
            text-align: center;
        }

        .text-right {
            text-align: right;
        }

        .status-lunas {
            font-weight: bold;
            color: #0f766e;
        }

        .status-belum {
            font-weight: bold;
            color: #b91c1c;
        }
    </style>
</head>
<body>

<h3>Rekap Pembayaran</h3>

<?php
    $bulanAngka = (int) $bulan;
?>

<p>
    <strong>Periode:</strong>
    <?php echo e(\Carbon\Carbon::create()->month($bulanAngka)->translatedFormat('F')); ?>

    <?php echo e($tahun); ?>

</p>

<table>
<thead>
<tr>
    <th width="4%">No</th>
    <th width="26%">Peserta</th>
    <th width="12%">Jenis</th>
    <th width="22%">Sekolah</th>
    <th width="12%">Tanggal</th>
    <th width="14%">Jumlah</th>
    <th width="10%">Status</th>
</tr>
</thead>

<tbody>
<?php $__empty_1 = true; $__currentLoopData = $pembayarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

<?php
    $namaPeserta = $p->jenis_peserta === 'home_private'
        ? $p->homePrivate?->nama_peserta
        : $p->peserta?->nama;

    $namaSekolah = $p->jenis_peserta === 'home_private'
        ? 'Home Private'
        : ($p->sekolah?->nama_sekolah ?? '-');
?>

<tr>
    <td class="text-center"><?php echo e($i + 1); ?></td>

    <td><?php echo e($namaPeserta ?? '-'); ?></td>

    <td class="text-center">
        <?php echo e($p->jenis_peserta === 'home_private' ? 'Home Private' : 'Sekolah'); ?>

    </td>

    <td><?php echo e($namaSekolah); ?></td>

    <td class="text-center">
        <?php echo e($p->tanggal_bayar
            ? $p->tanggal_bayar->format('d/m/Y')
            : '-'); ?>

    </td>

    <td class="text-right">
        Rp <?php echo e(number_format($p->jumlah ?? 0, 0, ',', '.')); ?>

    </td>

    <td class="text-center">
        <span class="<?php echo e($p->status === 'lunas' ? 'status-lunas' : 'status-belum'); ?>">
            <?php echo e(strtoupper($p->status)); ?>

        </span>
    </td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr>
    <td colspan="7" class="text-center">
        Tidak ada data pembayaran
    </td>
</tr>
<?php endif; ?>
</tbody>
</table>

<p style="margin-top: 12px;">
    <strong>Total Lunas:</strong>
    Rp <?php echo e(number_format($totalLunas, 0, ',', '.')); ?>

</p>

</body>
</html>
<?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/pembayaran/rekap-pdf.blade.php ENDPATH**/ ?>