<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="min-h-screen flex items-center justify-center px-4 bg-tranparent">

        <div class="w-full max-w-md">

            
            <div class="flex justify-center mb-8">
                <img
                    src="<?php echo e(asset('images/applogo.png')); ?>"
                    alt="MyRobo"
                    class="h-28 sm:h-32 md:h-40 transition"
                >
            </div>

            
            <div class="bg-white rounded-2xl shadow-md px-6 sm:px-8 py-8">

                <h2 class="text-center text-xl font-semibold text-gray-800 mb-6">
                    LOGIN
                </h2>

                
                <?php if($errors->any()): ?>
                    <div class="mb-4 text-sm text-red-600 text-center">
                        <?php echo e($errors->first()); ?>

                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('login')); ?>" class="space-y-5">
                    <?php echo csrf_field(); ?>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-600 mb-1">
                            Username
                        </label>
                        <input
                            type="text"
                            name="username"
                            value="<?php echo e(old('username')); ?>"
                            required
                            autofocus
                            class="w-full rounded-lg px-4 py-2.5
                                bg-gray-100 border border-gray-200
                                focus:outline-none focus:ring-2
                                focus:ring-[#8FBFC2]/70
                                focus:border-[#8FBFC2]"
                        >
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-600 mb-1">
                            Password
                        </label>
                        <input
                            type="password"
                            name="password"
                            required
                            class="w-full rounded-lg px-4 py-2.5
                                   bg-gray-100 border border-gray-200
                                   focus:outline-none focus:ring-2
                                   focus:ring-[#8FBFC2]/70
                                   focus:border-[#8FBFC2]"
                        >
                    </div>

                    
                    <button
                        type="submit"
                        class="w-full mt-2
                               bg-gradient-to-r from-[#8FBFC2] to-[#7AAEB1]
                               hover:from-[#7AAEB1] hover:to-[#6FA9AD]
                               text-white font-semibold
                               py-3 rounded-xl
                               shadow-sm transition-all duration-200">
                        Login
                    </button>
                </form>

            </div>

            
            <p class="mt-6 text-center text-xs text-gray-500">
                © <?php echo e(date('Y')); ?> MyRobo. All rights reserved.
            </p>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/auth/login.blade.php ENDPATH**/ ?>