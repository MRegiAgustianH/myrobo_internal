<?php $__env->startSection('header'); ?>
Profil Pengguna
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="space-y-6 max-w-3xl">

    
    <div class="bg-white p-6 rounded-lg shadow">
        <h3 class="font-semibold mb-4">Informasi Profil</h3>
        <?php echo $__env->make('profile.partials.update-profile-information-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    
    <div class="bg-white p-6 rounded-lg shadow">
        <h3 class="font-semibold mb-4">Ubah Password</h3>
        <?php echo $__env->make('profile.partials.update-password-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    
    <div class="bg-white p-6 rounded-lg shadow border border-red-200">
        <h3 class="font-semibold mb-4 text-red-600">Hapus Akun</h3>
        <?php echo $__env->make('profile.partials.delete-user-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/profile/edit.blade.php ENDPATH**/ ?>