<?php $__env->startSection('header'); ?>
Rekap Absensi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<form method="GET"
      action="<?php echo e(route('absensi.rekap.filter')); ?>"
      class="bg-[#F6FAFB] border border-[#E3EEF0]
             rounded-2xl shadow-sm mb-6 p-5">

    <div class="grid grid-cols-1 md:grid-cols-5 gap-4 items-end">

        
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">
                Jenis Peserta
            </label>
            <select name="jenis_peserta"
                    id="jenis_peserta"
                    class="w-full bg-white border border-[#E3EEF0]
                           rounded-lg px-3 py-2 text-sm">
                <option value="">Semua</option>
                <option value="sekolah"
                    <?php echo e(request('jenis_peserta') === 'sekolah' ? 'selected' : ''); ?>>
                    Sekolah
                </option>
                <option value="home_private"
                    <?php echo e(request('jenis_peserta') === 'home_private' ? 'selected' : ''); ?>>
                    Home Private
                </option>
            </select>
        </div>

        
        <div id="sekolah-wrapper">
            <label class="block text-sm font-medium text-gray-700 mb-1">
                Sekolah
            </label>

            <?php if(auth()->user()->isAdmin() || auth()->user()->role === 'sekretaris'): ?>
                <select name="sekolah_id"
                        id="sekolah_id"
                        class="w-full bg-white border border-[#E3EEF0]
                               rounded-lg px-3 py-2 text-sm">
                    <option value="">-- Semua Sekolah --</option>
                    <?php $__currentLoopData = $sekolahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s->id); ?>"
                            <?php echo e((string)request('sekolah_id') === (string)$s->id ? 'selected' : ''); ?>>
                            <?php echo e($s->nama_sekolah); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <?php else: ?>
                <input type="hidden"
                       id="sekolah_id"
                       name="sekolah_id"
                       value="<?php echo e(auth()->user()->sekolah_id); ?>">
                <div class="px-3 py-2 bg-white border border-[#E3EEF0]
                            rounded-lg text-sm text-gray-700">
                    <?php echo e(auth()->user()->sekolah->nama_sekolah); ?>

                </div>
            <?php endif; ?>
        </div>

        
        <div>
            <label class="block text-sm font-medium mb-1">Tanggal Mulai</label>
            <input type="date"
                   name="tanggal_mulai"
                   value="<?php echo e(request('tanggal_mulai')); ?>"
                   class="w-full bg-white border border-[#E3EEF0]
                          rounded-lg px-3 py-2 text-sm">
        </div>

        
        <div>
            <label class="block text-sm font-medium mb-1">Tanggal Selesai</label>
            <input type="date"
                   name="tanggal_selesai"
                   value="<?php echo e(request('tanggal_selesai')); ?>"
                   class="w-full bg-white border border-[#E3EEF0]
                          rounded-lg px-3 py-2 text-sm">
        </div>

        
        <div class="flex gap-2">
            <button
                class="flex-1 bg-[#8FBFC2] hover:bg-[#6FA9AD]
                       px-4 py-2 rounded-lg font-semibold">
                Tampilkan
            </button>

            <a href="<?php echo e(route('absensi.rekap.filter')); ?>"
               class="flex-1 border border-[#E3EEF0]
                      px-4 py-2 rounded-lg text-center text-sm">
                Reset
            </a>
        </div>

    </div>
</form>




<?php if(request()->filled('tanggal_mulai') && request()->filled('tanggal_selesai')): ?>
<form method="GET"
      action="<?php echo e(route('absensi.rekap.export-pdf')); ?>"
      target="_blank"
      class="mb-4">

    <input type="hidden" name="sekolah_id" value="<?php echo e(request('sekolah_id')); ?>">
    <input type="hidden" name="tanggal_mulai" value="<?php echo e(request('tanggal_mulai')); ?>">
    <input type="hidden" name="tanggal_selesai" value="<?php echo e(request('tanggal_selesai')); ?>">

    <button
        class="inline-flex items-center gap-2
               border border-[#E3EEF0]
               px-4 py-2 rounded-lg text-sm
               hover:bg-[#F6FAFB]">
        Export PDF
    </button>
</form>
<?php endif; ?>



<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

    
    <div>
        <h3 class="font-bold text-lg text-gray-800 mb-3 flex items-center gap-2">
            <span class="bg-[#8FBFC2] text-white p-1 rounded">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z" />
                </svg>
            </span>
            Absensi Instruktur
        </h3>

        
        <div class="space-y-4 md:hidden mb-6">
            <?php $__empty_1 = true; $__currentLoopData = $absensiInstrukturs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white border border-[#E3EEF0] rounded-xl p-4 shadow-sm text-sm">
                <div class="font-semibold text-gray-800">
                    <?php echo e($ai->instruktur->name); ?>

                </div>
                <div class="text-xs text-gray-600">
                    <?php echo e($ai->jadwal->sekolah->nama_sekolah ?? 'Home Private'); ?>

                </div>
                <div class="mt-2 text-xs">
                    <strong>Kegiatan:</strong> <?php echo e($ai->jadwal->nama_kegiatan ?? '-'); ?>

                </div>
                <div class="text-xs mt-1">
                    <?php echo e($ai->tanggal->format('d/m/Y')); ?>

                </div>
                <div class="mt-3">
                    <span class="px-2 py-1 rounded-full text-xs font-semibold
                        <?php if($ai->status === 'hadir'): ?> bg-green-100 text-green-700
                        <?php elseif($ai->status === 'sakit'): ?> bg-yellow-100 text-yellow-700
                        <?php elseif($ai->status === 'izin'): ?> bg-blue-100 text-blue-700
                        <?php else: ?> bg-red-100 text-red-700 <?php endif; ?>">
                        <?php echo e(ucfirst($ai->status)); ?>

                    </span>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-center text-gray-500 py-4 bg-gray-50 rounded-lg border border-dashed border-gray-300">
                Tidak ada data instruktur
            </div>
            <?php endif; ?>
        </div>

        
        <div class="hidden md:block bg-white border border-[#E3EEF0] rounded-2xl shadow-sm overflow-x-auto">
            <table class="min-w-full text-sm">
                <thead class="bg-[#F6FAFB] border-b border-[#E3EEF0]">
                    <tr>
                        <th class="px-4 py-2 text-left">No</th>
                        <th class="px-4 py-2 text-left">Instruktur</th>
                        <th class="px-4 py-2 text-left">Lokasi</th>
                        <th class="px-4 py-2 text-center">Tgl & Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-[#E3EEF0]">
                    <?php $__empty_1 = true; $__currentLoopData = $absensiInstrukturs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $ai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-4 py-2 text-gray-500"><?php echo e($i + 1); ?></td>
                        <td class="px-4 py-2 font-medium text-gray-900">
                            <?php echo e($ai->instruktur->name); ?>

                            <div class="text-xs text-gray-500 font-normal">
                                <?php echo e($ai->jadwal->nama_kegiatan ?? '-'); ?>

                            </div>
                        </td>
                        <td class="px-4 py-2">
                            <?php echo e($ai->jadwal->sekolah->nama_sekolah ?? 'Home Private'); ?>

                        </td>
                        <td class="px-4 py-2 text-center">
                            <div class="text-xs mb-1"><?php echo e($ai->tanggal->format('d/m/y')); ?></div>
                            <span class="px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wide
                                <?php if($ai->status === 'hadir'): ?> bg-green-100 text-green-700
                                <?php elseif($ai->status === 'sakit'): ?> bg-yellow-100 text-yellow-700
                                <?php elseif($ai->status === 'izin'): ?> bg-blue-100 text-blue-700
                                <?php else: ?> bg-red-100 text-red-700 <?php endif; ?>">
                                <?php echo e($ai->status); ?>

                            </span>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="px-4 py-8 text-center text-gray-500 italic">
                            Tidak ada data absensi instruktur
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div>
        <h3 class="font-bold text-lg text-gray-800 mb-3 flex items-center gap-2">
            <span class="bg-[#8FBFC2] text-white p-1 rounded">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
                </svg>
            </span>
            Absensi Peserta
        </h3>

        
        <div class="space-y-4 md:hidden">
            <?php $__empty_1 = true; $__currentLoopData = $absensis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $namaPeserta = $a->isSekolah() ? $a->peserta?->nama : $a->homePrivate?->nama_peserta;
                $namaSekolah = $a->jadwal?->sekolah?->nama_sekolah ?? 'Home Private';
            ?>
            <div class="bg-white border border-[#E3EEF0] rounded-xl p-4 shadow-sm text-sm">
                <div class="font-semibold text-gray-800">
                    <?php echo e($namaPeserta ?? '-'); ?>

                </div>
                <div class="text-xs text-gray-600">
                    <?php echo e($namaSekolah); ?>

                </div>
                <div class="mt-2 text-xs">
                    <strong>Kegiatan:</strong> <?php echo e($a->jadwal?->nama_kegiatan ?? '-'); ?>

                </div>
                <div class="text-xs mt-1">
                    <?php echo e(optional($a->tanggal)->format('d/m/Y')); ?>

                </div>
                <div class="mt-3">
                    <span class="px-2 py-1 rounded-full text-xs font-semibold
                        <?php if($a->status === 'hadir'): ?> bg-green-100 text-green-700
                        <?php elseif($a->status === 'sakit'): ?> bg-yellow-100 text-yellow-700
                        <?php elseif($a->status === 'izin'): ?> bg-blue-100 text-blue-700
                        <?php else: ?> bg-red-100 text-red-700 <?php endif; ?>">
                        <?php echo e(ucfirst($a->status)); ?>

                    </span>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-center text-gray-500 py-6 bg-gray-50 rounded-lg border border-dashed border-gray-300">
                Tidak ada data absensi peserta
            </div>
            <?php endif; ?>
        </div>

        
        <div class="hidden md:block bg-white border border-[#E3EEF0] rounded-2xl shadow-sm overflow-x-auto">
            <table class="min-w-full text-sm">
                <thead class="bg-[#F6FAFB] border-b border-[#E3EEF0]">
                    <tr>
                        <th class="px-4 py-2 text-left">No</th>
                        <th class="px-4 py-2 text-left">Peserta</th>
                        <th class="px-4 py-2 text-left">Lokasi</th>
                        <th class="px-4 py-2 text-center">Tgl & Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-[#E3EEF0]">
                    <?php $__empty_1 = true; $__currentLoopData = $absensis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $namaPeserta = $a->isSekolah() ? $a->peserta?->nama : $a->homePrivate?->nama_peserta;
                    ?>
                    <tr>
                        <td class="px-4 py-2 text-gray-500"><?php echo e($i + 1); ?></td>
                        <td class="px-4 py-2 font-medium text-gray-900">
                            <?php echo e($namaPeserta ?? '-'); ?>

                            <div class="text-xs text-gray-500 font-normal">
                                <?php echo e($a->jadwal?->nama_kegiatan ?? '-'); ?>

                            </div>
                        </td>
                        <td class="px-4 py-2">
                            <?php echo e($a->jadwal?->sekolah?->nama_sekolah ?? 'Home Private'); ?>

                        </td>
                        <td class="px-4 py-2 text-center">
                            <div class="text-xs mb-1"><?php echo e(optional($a->tanggal)->format('d/m/y')); ?></div>
                            <span class="px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wide
                                <?php if($a->status === 'hadir'): ?> bg-green-100 text-green-700
                                <?php elseif($a->status === 'sakit'): ?> bg-yellow-100 text-yellow-700
                                <?php elseif($a->status === 'izin'): ?> bg-blue-100 text-blue-700
                                <?php else: ?> bg-red-100 text-red-700 <?php endif; ?>">
                                <?php echo e($a->status); ?>

                            </span>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="px-4 py-8 text-center text-gray-500 italic">
                            Tidak ada data absensi peserta
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const jenisSelect   = document.getElementById('jenis_peserta');
    const sekolahWrap   = document.getElementById('sekolah-wrapper');
    const sekolahSelect = document.getElementById('sekolah_id');

    function toggleSekolah() {
        if (jenisSelect.value === 'home_private') {
            sekolahWrap.classList.add('hidden');

            // kosongkan value agar tidak ikut terkirim
            if (sekolahSelect) {
                sekolahSelect.value = '';
            }
        } else {
            sekolahWrap.classList.remove('hidden');
        }
    }

    jenisSelect.addEventListener('change', toggleSekolah);

    // jalankan saat pertama load (penting untuk reload halaman)
    toggleSekolah();
});
</script>
<?php $__env->stopPush(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/absensi/rekap-filter.blade.php ENDPATH**/ ?>