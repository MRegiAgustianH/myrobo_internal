

<?php $__env->startSection('header'); ?>
Edit Pengeluaran
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('keuangan.update', $keuangan->id)); ?>" method="POST"
      class="bg-white p-6 rounded-xl border max-w-xl">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>

<div class="mb-4">
    <label>Tanggal</label>
    <input type="date" name="tanggal"
        value="<?php echo e($keuangan->tanggal); ?>"
        class="w-full border rounded px-3 py-2">
</div>

<div class="mb-4">
    <label>Kategori</label>
    <input type="text" name="kategori"
        value="<?php echo e($keuangan->kategori); ?>"
        class="w-full border rounded px-3 py-2">
</div>

<div class="mb-4">
    <label>Jumlah</label>
    <input type="number" name="jumlah"
        value="<?php echo e($keuangan->jumlah); ?>"
        class="w-full border rounded px-3 py-2">
</div>

<div class="mb-4">
    <label>Deskripsi</label>
    <textarea name="deskripsi"
        class="w-full border rounded px-3 py-2"><?php echo e($keuangan->deskripsi); ?></textarea>
</div>

<button class="bg-[#8FBFC2] px-5 py-2 rounded">
    Update
</button>

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/keuangan/edit.blade.php ENDPATH**/ ?>