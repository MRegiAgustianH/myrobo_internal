<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'MyRobo Training')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="font-sans antialiased">
    
    <div class="h-screen w-screen flex items-center justify-center bg-[#7CCCCC] overflow-hidden">
        <?php echo e($slot); ?>

    </div>
</body>
</html>
<?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/layouts/guest.blade.php ENDPATH**/ ?>