

<?php $__env->startSection('header'); ?>
Indikator Kompetensi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="mb-4">
    <p class="text-sm text-gray-500">Materi</p>
    <h2 class="text-lg font-semibold text-gray-800">
        <?php echo e($materi->nama_materi); ?>

    </h2>

    <p class="text-sm text-gray-500 mt-2">Kompetensi</p>
    <h3 class="font-medium text-gray-700">
        <?php echo e($kompetensi->nama_kompetensi); ?>

    </h3>
</div>


<?php if(session('success')): ?>
<div class="mb-4 p-3 bg-green-100 text-green-700 rounded text-sm">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="mb-4 p-3 bg-red-100 text-red-700 rounded text-sm">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>


<div class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3 mb-6">

    <a href="<?php echo e(route('materi.kompetensi.index', $materi->id)); ?>"
       class="text-sm text-gray-600 hover:underline">
        ← Kembali ke Kompetensi
    </a>

    <button onclick="openCreateModal()"
    class="inline-flex items-center gap-2
            bg-[#8FBFC2] hover:bg-[#6FA9AD]
            text-white px-4 py-2 rounded-lg text-sm transition">
        <i data-feather="plus" class="w-4 h-4"></i>
        Tambah Indikator
    </button>

</div>


<div class="grid grid-cols-1 gap-4 md:hidden">

<?php $__empty_1 = true; $__currentLoopData = $indikators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="bg-white rounded-xl shadow p-4 space-y-3">

    <p class="font-semibold text-gray-800">
        <?php echo e($i->nama_indikator); ?>

    </p>

    <div class="flex gap-2 pt-2 border-t">
        <button type="button"
        onclick='openEditModal(<?php echo json_encode($i, 15, 512) ?>)'
        class="bg-blue-100 text-blue-700 px-3 py-1 rounded text-xs">
            Edit
        </button>


        <button type="button"
        onclick="confirmDelete(<?php echo e($i->id); ?>)"
        class="bg-red-100 text-red-700 px-3 py-1 rounded text-xs">
            Hapus
        </button>

    </div>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<div class="bg-white rounded-xl shadow p-6 text-center text-sm text-gray-500">
    Belum ada indikator untuk kompetensi ini
</div>
<?php endif; ?>

</div>


<div class="hidden md:block bg-white rounded-xl shadow overflow-x-auto">

<table class="min-w-full text-sm">
    <thead class="bg-gray-50 border-b">
        <tr class="text-gray-600 uppercase text-xs tracking-wider">
            <th class="px-4 py-3 text-left">
                Nama Indikator
            </th>
            <th class="px-4 py-3 text-center w-40">
                Aksi
            </th>
        </tr>
    </thead>

    <tbody class="divide-y">
    <?php $__empty_1 = true; $__currentLoopData = $indikators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="hover:bg-gray-50 transition">
            <td class="px-4 py-3 font-medium">
                <?php echo e($i->nama_indikator); ?>

            </td>

            <td class="px-4 py-3 text-center">
                <div class="inline-flex gap-2 justify-center">

                    <button type="button"
                    onclick='openEditModal(<?php echo json_encode($i, 15, 512) ?>)'
                    class="bg-blue-100 text-blue-700 px-3 py-1 rounded text-xs">
                        Edit
                    </button>


                    <button type="button"
                    onclick="confirmDelete(<?php echo e($i->id); ?>)"
                    class="bg-red-100 text-red-700 px-3 py-1 rounded text-xs">
                        Hapus
                    </button>


                </div>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="2"
                class="px-4 py-6 text-center text-gray-500">
                Belum ada indikator untuk kompetensi ini
            </td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>

</div>

<?php $__env->startPush('scripts'); ?>
<script>
/* ================= FORM TEMPLATE ================= */
function indikatorForm(data = {}) {
    return `
        <input type="hidden" id="csrf" value="<?php echo e(csrf_token()); ?>">
        <div class="space-y-4 text-left text-sm">
            <div>
                <label class="font-medium">Nama Indikator</label>
                <input id="nama_indikator"
                    class="w-full border rounded-lg px-3 py-2"
                    value="${data.nama_indikator ?? ''}">
            </div>
        </div>
    `;
}

/* ================= CREATE ================= */
function openCreateModal() {
    Swal.fire({
        title: 'Tambah Indikator',
        html: indikatorForm(),
        showConfirmButton: false,
        width: 500,
        footer: modalActions(
            "<?php echo e(route('materi.kompetensi.indikator.store', [$materi->id, $kompetensi->id])); ?>",
            'POST'
        )
    });
}

/* ================= EDIT ================= */
function openEditModal(data) {
    Swal.fire({
        title: 'Edit Indikator',
        html: indikatorForm(data),
        showConfirmButton: false,
        width: 500,
        footer: modalActions(
            `/admin/materi/<?php echo e($materi->id); ?>/kompetensi/<?php echo e($kompetensi->id); ?>/indikator/${data.id}`,
            'PUT'
        )
    });
}

/* ================= ACTION BUTTON ================= */
function modalActions(action, method) {
    return `
        <div class="flex gap-2">
            <button onclick="submitForm('${action}','${method}')"
                class="bg-[#8FBFC2] text-white px-4 py-2 rounded">
                Simpan
            </button>
            <button onclick="Swal.close()"
                class="border px-4 py-2 rounded">
                Batal
            </button>
        </div>
    `;
}

/* ================= SUBMIT ================= */
function submitForm(action, method) {
    const nama = document.getElementById('nama_indikator').value;

    if (!nama) {
        Swal.showValidationMessage('Nama indikator wajib diisi');
        return;
    }

    const form = document.createElement('form');
    form.method = 'POST';
    form.action = action;

    form.innerHTML = `
        <input type="hidden" name="_token" value="${document.getElementById('csrf').value}">
        ${method !== 'POST'
            ? `<input type="hidden" name="_method" value="${method}">`
            : ''
        }
        <input type="hidden" name="nama_indikator" value="${nama}">
    `;

    document.body.appendChild(form);
    form.submit();
}

/* ================= DELETE ================= */
function confirmDelete(id) {
    Swal.fire({
        title: 'Hapus Indikator?',
        text: 'Indikator akan dihapus permanen',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, hapus',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {

            const form = document.createElement('form');
            form.method = 'POST';
            form.action =
                `/admin/materi/<?php echo e($materi->id); ?>/kompetensi/<?php echo e($kompetensi->id); ?>/indikator/${id}`;

            form.innerHTML = `
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="_method" value="DELETE">
            `;

            document.body.appendChild(form);
            form.submit();
        }
    });
}
</script>
<?php $__env->stopPush(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/admin/materi/kompetensi/indikator/index.blade.php ENDPATH**/ ?>