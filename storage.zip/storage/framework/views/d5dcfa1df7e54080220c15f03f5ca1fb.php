<?php
    $bolehAbsen =
        auth()->user()->isAdmin()
        || auth()->user()->isAdminSekolah()
        || (auth()->user()->isInstruktur() && $jadwal->isDalamJamAbsensi());
?>

<?php $__env->startSection('header'); ?>
Absensi –
<?php echo e($jadwal->jenis_jadwal === 'sekolah'
    ? $jadwal->sekolah->nama_sekolah
    : $jadwal->homePrivate->nama_kegiatan); ?>

/ <?php echo e($jadwal->tanggal_mulai); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<?php if(session('success')): ?>
<div class="mb-4 p-3 rounded-xl bg-green-100 text-green-700 border text-sm">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="mb-4 p-3 rounded-xl bg-red-100 text-red-700 border text-sm">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>




<?php if(auth()->user()->isInstruktur()): ?>
<form
    action="<?php echo e(route('instruktur.absensi.store', $jadwal)); ?>"
    method="POST"
    class="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-2xl"
>
<?php echo csrf_field(); ?>

<h3 class="font-semibold mb-3">Absensi Instruktur</h3>

<?php if(!empty($absensiInstruktur)): ?>
    <p class="text-sm text-gray-600 mb-2">
        Status saat ini:
        <strong class="capitalize"><?php echo e($absensiInstruktur->status); ?></strong>
    </p>
<?php endif; ?>

<div class="flex flex-wrap gap-4 mb-3">
<?php $__currentLoopData = ['hadir','sakit','izin','alfa']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<label class="flex items-center gap-2">
    <input
        type="radio"
        name="status"
        value="<?php echo e($status); ?>"
        <?php echo e(!$bolehAbsen ? 'disabled' : ''); ?>

        <?php echo e($absensiInstruktur?->status === $status ? 'checked' : ''); ?>

        required
    >
    <span class="capitalize"><?php echo e($status); ?></span>
</label>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<textarea
    name="keterangan"
    class="w-full border rounded-lg px-3 py-2 text-sm"
    placeholder="Keterangan (opsional)"
    <?php echo e(!$bolehAbsen ? 'disabled' : ''); ?>

><?php echo e($absensiInstruktur->keterangan ?? ''); ?></textarea>

<?php if($bolehAbsen): ?>
<button
    type="submit"
    class="mt-3 px-4 py-2 bg-blue-600 text-white rounded-lg"
>
    Simpan Absensi Instruktur
</button>
<?php else: ?>
<div class="mt-2 text-sm text-red-600">
    Absensi instruktur terkunci. Hanya dapat diedit oleh admin.
</div>
<?php endif; ?>
</form>
<?php endif; ?>




<form action="<?php echo e(route('absensi.store', $jadwal)); ?>" method="POST">
<?php echo csrf_field(); ?>


<div class="space-y-4 md:hidden">
<?php $__currentLoopData = $pesertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
    $key = $p->id;
    $absen = $absensiMap[$key] ?? null;
    $namaPeserta = $jadwal->jenis_jadwal === 'sekolah'
        ? $p->nama
        : $p->nama_peserta;
?>

<div class="bg-white border rounded-2xl p-4 shadow-sm">
<input type="hidden" name="absensi[<?php echo e($key); ?>][__present]" value="1">

<div class="font-semibold mb-3"><?php echo e($namaPeserta); ?></div>

<div class="grid grid-cols-2 gap-3 mb-3">
<?php $__currentLoopData = ['hadir','sakit','izin','alfa']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<label class="flex items-center gap-2">
<input
    type="radio"
    name="absensi[<?php echo e($key); ?>][status]"
    value="<?php echo e($status); ?>"
    <?php echo e(!$bolehAbsen ? 'disabled' : ''); ?>

    <?php echo e($absen?->status === $status ? 'checked' : ''); ?>

>
<span class="capitalize"><?php echo e($status); ?></span>
</label>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<input
    type="text"
    name="absensi[<?php echo e($key); ?>][keterangan]"
    value="<?php echo e($absen->keterangan ?? ''); ?>"
    placeholder="Keterangan"
    class="w-full border rounded-lg px-3 py-2 text-sm"
    <?php echo e(!$bolehAbsen ? 'disabled' : ''); ?>

>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<div class="hidden md:block bg-white border rounded-2xl shadow-sm mt-4 overflow-x-auto">
<table class="min-w-full text-sm">
<thead>
<tr class="bg-gray-50">
    <th class="px-3 py-2">No</th>
    <th class="px-3 py-2 text-left">Nama Peserta</th>
    <th class="px-3 py-2 text-center">H</th>
    <th class="px-3 py-2 text-center">S</th>
    <th class="px-3 py-2 text-center">I</th>
    <th class="px-3 py-2 text-center">A</th>
    <th class="px-3 py-2 text-left">Keterangan</th>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $pesertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
    $key = $p->id;
    $absen = $absensiMap[$key] ?? null;
    $namaPeserta = $jadwal->jenis_jadwal === 'sekolah'
        ? $p->nama
        : $p->nama_peserta;
?>
<tr class="border-t">
<input type="hidden" name="absensi[<?php echo e($key); ?>][__present]" value="1">

<td class="px-3 py-2"><?php echo e($i + 1); ?></td>
<td class="px-3 py-2 font-medium"><?php echo e($namaPeserta); ?></td>

<?php $__currentLoopData = ['hadir','sakit','izin','alfa']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<td class="text-center">
<input
    type="radio"
    name="absensi[<?php echo e($key); ?>][status]"
    value="<?php echo e($status); ?>"
    <?php echo e(!$bolehAbsen ? 'disabled' : ''); ?>

    <?php echo e($absen?->status === $status ? 'checked' : ''); ?>

>
</td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<td class="px-3 py-2">
<input
    type="text"
    name="absensi[<?php echo e($key); ?>][keterangan]"
    value="<?php echo e($absen->keterangan ?? ''); ?>"
    class="w-full border rounded px-2 py-1 text-sm"
    <?php echo e(!$bolehAbsen ? 'disabled' : ''); ?>

>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>

<?php if($bolehAbsen): ?>
<div class="mt-6">
<button
    type="submit"
    class="px-6 py-3 bg-[#8FBFC2] rounded-xl font-semibold text-gray-900"
>
    Simpan Absensi Peserta
</button>
</div>
<?php else: ?>
<div class="mt-4 text-sm text-red-600">
    Absensi peserta terkunci. Hanya dapat diedit oleh admin.
</div>
<?php endif; ?>

</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/absensi/index.blade.php ENDPATH**/ ?>