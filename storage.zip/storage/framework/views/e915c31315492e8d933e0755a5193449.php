<?php $__env->startSection('header'); ?>
Dashboard Instruktur
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>




<div
    class="bg-[#F6FAFB] border border-[#E3EEF0]
           rounded-2xl shadow-sm p-5 mb-6">

    <p class="text-sm text-gray-500">Selamat datang</p>

    <p class="text-lg font-semibold text-gray-800">
        <?php echo e(Auth::user()->name); ?>

    </p>

    <p class="text-xs text-gray-500 capitalize">
        Instruktur
    </p>
</div>




<div class="mb-8">

    <h2
        class="text-sm font-semibold text-gray-800 mb-3
               flex items-center gap-2">
        <i data-feather="calendar" class="w-4 h-4 text-gray-500"></i>
        Jadwal Hari Ini
    </h2>

    <?php $__empty_1 = true; $__currentLoopData = $jadwalsHariIni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div
            class="bg-white border border-[#E3EEF0]
                   rounded-2xl shadow-sm p-4 mb-3
                   hover:bg-[#F6FAFB] transition">

            <p class="font-semibold text-sm text-gray-800">
                <?php echo e($j->nama_kegiatan); ?>

            </p>

            <div class="mt-2 text-xs text-gray-600 space-y-1">

                <p class="flex items-center gap-2">
                    <i data-feather="home" class="w-3.5 h-3.5"></i>
                    <?php echo e($j->sekolah?->nama_sekolah ?? 'Home Private'); ?>

                </p>


                <p class="flex items-center gap-2">
                    <i data-feather="clock" class="w-3.5 h-3.5"></i>
                    <?php echo e($j->jam_mulai); ?> – <?php echo e($j->jam_selesai); ?>

                </p>

            </div>

            <a
                href="<?php echo e(route('absensi.index', $j->id)); ?>"
                class="inline-flex items-center gap-2 mt-4
                       bg-[#8FBFC2] hover:bg-[#6FA9AD]
                       text-gray-900 text-xs font-medium
                       px-4 py-2 rounded-lg transition">

                <i data-feather="edit-3" class="w-3.5 h-3.5"></i>
                Isi Absensi
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div
            class="bg-[#F6FAFB] border border-[#E3EEF0]
                   text-center text-sm text-gray-500
                   py-6 rounded-xl">

            Tidak ada jadwal hari ini
        </div>
    <?php endif; ?>
</div>




<div>

    <h2
        class="text-sm font-semibold text-gray-800 mb-3
               flex items-center gap-2">
        <i data-feather="calendar-range" class="w-4 h-4 text-gray-500"></i>
        Jadwal Minggu Ini
    </h2>

    <div class="space-y-3">
        <?php $__empty_1 = true; $__currentLoopData = $jadwalsMingguan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div
                class="bg-white border border-[#E3EEF0]
                       rounded-xl shadow-sm p-4
                       flex flex-col sm:flex-row
                       sm:justify-between sm:items-center gap-3">

                <div>
                    <p class="font-medium text-sm text-gray-800">
                        <?php echo e($j->nama_kegiatan); ?>

                    </p>

                    <p class="text-xs text-gray-500 mt-0.5">
                        <?php echo e(\Carbon\Carbon::parse($j->tanggal_mulai)->format('d M Y')); ?>

                        • <?php echo e($j->jam_mulai); ?> – <?php echo e($j->jam_selesai); ?>

                    </p>
                </div>

                <span class="text-xs bg-[#F6FAFB]
                    border border-[#E3EEF0]
                    px-3 py-1 rounded-full
                    text-gray-700">

                    <?php echo e($j->sekolah?->nama_sekolah ?? 'Home Private'); ?>

                </span>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div
                class="bg-[#F6FAFB] border border-[#E3EEF0]
                       text-center text-sm text-gray-500
                       py-5 rounded-xl">

                Tidak ada jadwal minggu ini
            </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/dashboard-instruktur.blade.php ENDPATH**/ ?>