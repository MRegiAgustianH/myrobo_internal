<?php $__env->startSection('header'); ?>
Dashboard Admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-5 mb-8">

    
    <div class="bg-white rounded-xl p-5 shadow-sm border hover:shadow-md transition">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-xs text-gray-500 uppercase">Sekolah</p>
                <p class="text-3xl font-semibold text-gray-800">
                    <?php echo e($totalSekolah); ?>

                </p>
            </div>
            <div class="p-3 rounded-lg bg-[#8FBFC2]/20">
                <i data-feather="home" class="w-6 h-6 text-[#5a8f94]"></i>
            </div>
        </div>
    </div>

    
    <div class="bg-white rounded-xl p-5 shadow-sm border hover:shadow-md transition">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-xs text-gray-500 uppercase">Peserta</p>
                <p class="text-3xl font-semibold text-gray-800">
                    <?php echo e($totalPeserta); ?>

                </p>
            </div>
            <div class="p-3 rounded-lg bg-blue-100">
                <i data-feather="users" class="w-6 h-6 text-blue-600"></i>
            </div>
        </div>
    </div>

    

    
    <div class="bg-white rounded-xl p-5 shadow-sm border hover:shadow-md transition">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-xs text-gray-500 uppercase">Instruktur</p>
                <p class="text-3xl font-semibold text-gray-800">
                    <?php echo e($totalInstruktur); ?>

                </p>
            </div>
            <div class="p-3 rounded-lg bg-emerald-100">
                <i data-feather="user-check" class="w-6 h-6 text-emerald-600"></i>
            </div>
        </div>
    </div>

    
    <div class="bg-white rounded-xl p-5 shadow-sm border hover:shadow-md transition">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-xs text-gray-500 uppercase">Jadwal</p>
                <p class="text-3xl font-semibold text-gray-800">
                    <?php echo e($totalJadwal); ?>

                </p>
            </div>
            <div class="p-3 rounded-lg bg-purple-100">
                <i data-feather="calendar" class="w-6 h-6 text-purple-600"></i>
            </div>
        </div>
    </div>

    
    <div class="bg-white rounded-xl p-5 shadow-sm border hover:shadow-md transition">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-xs text-gray-500 uppercase">Belum Lunas</p>
                <p class="text-3xl font-semibold text-red-600">
                    <?php echo e($pembayaranBelum); ?>

                </p>
            </div>
            <div class="p-3 rounded-lg bg-red-100">
                <i data-feather="alert-circle" class="w-6 h-6 text-red-600"></i>
            </div>
        </div>
    </div>

    
    <div class="bg-white rounded-xl p-5 shadow-sm border hover:shadow-md transition">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-xs text-gray-500 uppercase">Lunas</p>
                <p class="text-3xl font-semibold text-emerald-600">
                    <?php echo e($pembayaranLunas); ?>

                </p>
            </div>
            <div class="p-3 rounded-lg bg-emerald-100">
                <i data-feather="check-circle" class="w-6 h-6 text-emerald-600"></i>
            </div>
        </div>
    </div>

</div>


<div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">

    
    <div class="bg-white rounded-xl p-6 shadow-sm border">
        <p class="text-xs text-gray-500 uppercase mb-1">
            Uang Masuk (<?php echo e(\Carbon\Carbon::create()->month($bulan)->translatedFormat('F')); ?> <?php echo e($tahun); ?>)
        </p>
        <p class="text-3xl font-bold text-emerald-600">
            Rp <?php echo e(number_format($uangMasuk, 0, ',', '.')); ?>

        </p>
    </div>

    
    <div class="bg-white rounded-xl p-6 shadow-sm border">
        <p class="text-xs text-gray-500 uppercase mb-1">
            Uang Keluar (<?php echo e(\Carbon\Carbon::create()->month($bulan)->translatedFormat('F')); ?> <?php echo e($tahun); ?>)
        </p>
        <p class="text-3xl font-bold text-red-600">
            Rp <?php echo e(number_format($uangKeluar, 0, ',', '.')); ?>

        </p>
    </div>

    
    <div class="bg-white rounded-xl p-6 shadow-sm border">
        <p class="text-xs text-gray-500 uppercase mb-1">
            Saldo Bersih
        </p>
        <p class="text-3xl font-bold <?php echo e($saldo >= 0 ? 'text-blue-600' : 'text-red-600'); ?>">
            Rp <?php echo e(number_format($saldo, 0, ',', '.')); ?>

        </p>
    </div>

</div>


<div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">

    
    <div class="bg-white rounded-xl shadow-sm border p-6">
        <h3 class="font-semibold text-gray-700 mb-4 flex items-center gap-2">
            <i data-feather="grid" class="w-4 h-4"></i>
            Manajemen Pelatihan
        </h3>

        <div class="space-y-2 text-sm">
            <a href="<?php echo e(route('sekolah.index')); ?>"
               class="flex justify-between items-center p-3 rounded-lg hover:bg-gray-50">
                <span>Kelola Sekolah</span>
                <i data-feather="chevron-right" class="w-4 h-4"></i>
            </a>
            <a href="<?php echo e(route('home-private.index')); ?>"
               class="flex justify-between items-center p-3 rounded-lg hover:bg-gray-50">
                <span>Kelola Home Private</span>
                <i data-feather="chevron-right" class="w-4 h-4"></i>
            </a>
        </div>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border p-6">
        <h3 class="font-semibold text-gray-700 mb-4 flex items-center gap-2">
            <i data-feather="book-open" class="w-4 h-4"></i>
            Akademik
        </h3>

        <div class="space-y-2 text-sm">
            <a href="<?php echo e(route('admin.materi.index')); ?>"
               class="flex justify-between items-center p-3 rounded-lg hover:bg-gray-50">
                <span>Materi</span>
                <i data-feather="chevron-right" class="w-4 h-4"></i>
            </a>

            <a href="<?php echo e(route('jadwal.index')); ?>"
               class="flex justify-between items-center p-3 rounded-lg hover:bg-gray-50">
                <span>Jadwal</span>
                <i data-feather="chevron-right" class="w-4 h-4"></i>
            </a>

            <a href="<?php echo e(route('admin.rapor-tugas.index')); ?>"
               class="flex justify-between items-center p-3 rounded-lg hover:bg-gray-50">
                <span>Rapor</span>
                <i data-feather="chevron-right" class="w-4 h-4"></i>
            </a>
        </div>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border p-6">
        <h3 class="font-semibold text-gray-700 mb-4 flex items-center gap-2">
            <i data-feather="credit-card" class="w-4 h-4"></i>
            Keuangan
        </h3>

        <div class="space-y-2 text-sm">
            <a href="<?php echo e(route('pembayaran.index')); ?>"
               class="flex justify-between items-center p-3 rounded-lg hover:bg-gray-50">
                <span>Pembayaran</span>
                <i data-feather="chevron-right" class="w-4 h-4"></i>
            </a>

            <a href="<?php echo e(route('pembayaran.rekap')); ?>"
               class="flex justify-between items-center p-3 rounded-lg hover:bg-gray-50">
                <span>Rekap Pembayaran</span>
                <i data-feather="chevron-right" class="w-4 h-4"></i>
            </a>
            <a href="<?php echo e(route('keuangan.index')); ?>"
               class="flex justify-between items-center p-3 rounded-lg hover:bg-gray-50">
                <span>Pengeluaran</span>
                <i data-feather="chevron-right" class="w-4 h-4"></i>
            </a>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/dashboard.blade.php ENDPATH**/ ?>