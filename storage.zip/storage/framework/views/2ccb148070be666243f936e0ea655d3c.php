

<?php $__env->startSection('header'); ?>
Indikator Kompetensi – <?php echo e($kompetensi->nama_kompetensi); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<?php if(session('success')): ?>
<div class="mb-4 p-3 bg-green-100 text-green-700 rounded text-sm">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="mb-4 p-3 bg-red-100 text-red-700 rounded text-sm">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>


<div class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3 mb-5">
    <a href="<?php echo e(route('kompetensi.index')); ?>"
       class="text-sm text-gray-600 hover:underline">
        ← Kembali ke Kompetensi
    </a>

    <a href="<?php echo e(route('kompetensi.indikator.create', $kompetensi->id)); ?>"
       class="inline-flex items-center gap-2 bg-[#8FBFC2] hover:bg-[#6FA9AD] text-white px-4 py-2 rounded-lg text-sm transition">
        <i data-feather="plus" class="w-4 h-4"></i>
        Tambah Indikator
    </a>
</div>


<div class="grid grid-cols-1 gap-4 md:hidden">

<?php $__empty_1 = true; $__currentLoopData = $indikators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="bg-white rounded-xl shadow p-4 space-y-3">

    <div>
        <p class="font-semibold text-gray-800">
            <?php echo e($i->nama_indikator); ?>

        </p>
    </div>

    <div class="flex gap-2 pt-2">
        <a href="<?php echo e(route('kompetensi.indikator.edit', [$kompetensi->id, $i->id])); ?>"
           class="flex-1 bg-blue-100 text-blue-700 text-xs py-2 rounded text-center">
            Edit
        </a>

        <form action="<?php echo e(route('kompetensi.indikator.destroy', [$kompetensi->id, $i->id])); ?>"
              method="POST"
              onsubmit="return confirm('Hapus indikator ini?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button
                class="bg-red-100 text-red-700 text-xs px-3 py-2 rounded">
                Hapus
            </button>
        </form>
    </div>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<div class="bg-white rounded-xl shadow p-6 text-center text-sm text-gray-500">
    Belum ada indikator
</div>
<?php endif; ?>

</div>


<div class="hidden md:block bg-white rounded-lg shadow overflow-x-auto">

<table class="min-w-full text-sm">
    <thead class="bg-gray-50 border-b">
        <tr class="text-gray-600 uppercase text-xs tracking-wider">
            <th class="px-4 py-3 text-left">
                Nama Indikator
            </th>
            <th class="px-4 py-3 text-center w-40">
                Aksi
            </th>
        </tr>
    </thead>

    <tbody class="divide-y">
    <?php $__empty_1 = true; $__currentLoopData = $indikators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="hover:bg-gray-50 transition">
            <td class="px-4 py-3 font-medium">
                <?php echo e($i->nama_indikator); ?>

            </td>

            <td class="px-4 py-3 text-center">
                <div class="inline-flex gap-2 justify-center">
                    <a href="<?php echo e(route('kompetensi.indikator.edit', [$kompetensi->id, $i->id])); ?>"
                       class="bg-blue-100 text-blue-700 px-3 py-1 rounded text-xs">
                        Edit
                    </a>

                    <form action="<?php echo e(route('kompetensi.indikator.destroy', [$kompetensi->id, $i->id])); ?>"
                          method="POST"
                          onsubmit="return confirm('Hapus indikator ini?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button
                            class="bg-red-100 text-red-700 px-3 py-1 rounded text-xs">
                            Hapus
                        </button>
                    </form>
                </div>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="2"
                class="px-4 py-6 text-center text-gray-500">
                Belum ada indikator
            </td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/indikator/index.blade.php ENDPATH**/ ?>