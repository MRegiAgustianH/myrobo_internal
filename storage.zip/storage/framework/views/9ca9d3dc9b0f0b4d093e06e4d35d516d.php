<?php
    $rapor = $rapor ?? null;
    $readonly = $readonly ?? false;
?>

<div class="space-y-8">

<?php $__empty_1 = true; $__currentLoopData = $kompetensis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kompetensi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="bg-white border rounded-2xl p-6 shadow-sm">

    <h4 class="font-semibold text-gray-800 mb-5">
        <?php echo e($kompetensi->nama_kompetensi); ?>

    </h4>

    <div class="space-y-5">
    <?php $__empty_2 = true; $__currentLoopData = $kompetensi->indikatorKompetensis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indikator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>

        <?php
            $nilaiLama = old(
                "nilai.$indikator->id",
                optional($rapor?->nilaiRapors
                    ->firstWhere('indikator_kompetensi_id', $indikator->id)
                )->nilai
            );
        ?>

        <div class="flex flex-col md:flex-row md:items-center gap-4">
            <div class="md:flex-1 text-sm text-gray-700">
                <?php echo e($indikator->nama_indikator); ?>

            </div>

            <div class="flex gap-6 text-sm">
                <?php $__currentLoopData = ['C'=>'Cukup','B'=>'Baik','SB'=>'Sangat Baik']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="flex items-center gap-1">
                        <input type="radio"
                               name="nilai[<?php echo e($indikator->id); ?>]"
                               value="<?php echo e($k); ?>"
                               class="nilai-indikator"
                               <?php echo e($readonly ? 'disabled' : ''); ?>

                               <?php if($nilaiLama === $k): echo 'checked'; endif; ?>
                               required>
                        <?php echo e($label); ?>

                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
        <div class="text-sm text-gray-500 italic">
            Belum ada indikator untuk kompetensi ini
        </div>
    <?php endif; ?>
    </div>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<div class="text-sm text-gray-500 italic">
    Tidak ada kompetensi pada materi ini
</div>
<?php endif; ?>

</div>
<?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/admin/rapor/_kompetensi_indikator.blade.php ENDPATH**/ ?>