<?php $__env->startSection('header'); ?>
Manajemen Materi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3 mb-5">
    <h2 class="text-lg font-semibold text-gray-700">
        Daftar Materi
    </h2>

    <?php if(! $readonly): ?>
    <button onclick="openCreateModal()"
        class="inline-flex items-center gap-2 bg-[#8FBFC2] hover:bg-[#6FA9AD] text-white px-4 py-2 rounded-lg text-sm transition">
        <i data-feather="plus" class="w-4 h-4"></i>
        Tambah Materi
    </button>
    <?php endif; ?>

</div>

<?php if(session('success')): ?>
<div class="mb-4 p-3 rounded bg-green-100 text-green-700">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>


<div class="grid grid-cols-1 gap-4 md:hidden">

<?php $__currentLoopData = $materis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="bg-white rounded-xl shadow p-4 space-y-3">

    <div>
        <p class="font-semibold text-gray-800">
            <?php echo e($m->nama_materi); ?>

        </p>
        <p class="text-xs text-gray-500 line-clamp-2">
            <?php echo e($m->deskripsi ?? '—'); ?>

        </p>
    </div>

    <div class="flex justify-between items-center text-sm">
        <span class="text-gray-500">Status</span>
        <span class="px-3 py-1 text-xs rounded-full
            <?php echo e($m->status === 'aktif' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'); ?>">
            <?php echo e(ucfirst($m->status)); ?>

        </span>
    </div>

    <div class="flex flex-wrap gap-2 pt-3">

        
        <a href="<?php echo e(route('materi.modul.index', $m->id)); ?>"
        class="flex-1 bg-indigo-100 text-indigo-700 text-xs py-2 rounded text-center">
            Modul
        </a>

        
        <a href="<?php echo e(route('materi.kompetensi.index', $m->id)); ?>"
        class="flex-1 bg-green-100 text-green-700 text-xs py-2 rounded text-center">
            Kompetensi
        </a>

        
        <?php if(! $readonly): ?>
            <button onclick='openEditModal(<?php echo json_encode($m, 15, 512) ?>)'
                class="flex-1 bg-yellow-100 text-yellow-700 text-xs py-2 rounded">
                Edit
            </button>

            <form action="<?php echo e(route('admin.materi.destroy',$m->id)); ?>"
                method="POST"
                onsubmit="return confirmDelete(event)">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button
                    class="bg-red-100 text-red-700 text-xs px-3 py-2 rounded">
                    Hapus
                </button>
            </form>
        <?php endif; ?>
    </div>



</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>


<div class="hidden md:block bg-white rounded-lg shadow overflow-x-auto">

<table class="min-w-full text-sm">
<thead class="bg-gray-100">
<tr>
    <th class="px-4 py-3 text-left">Nama Materi</th>
    <th class="px-4 py-3 text-left">Deskripsi</th>
    <th class="px-4 py-3 text-center">Status</th>
    <th class="px-4 py-3 w-48 text-center">Aksi</th>
</tr>
</thead>

<tbody class="divide-y">
<?php $__currentLoopData = $materis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr class="hover:bg-gray-50 transition">
    <td class="px-4 py-2 font-medium">
        <?php echo e($m->nama_materi); ?>

    </td>

    <td class="px-4 py-2 text-gray-600 max-w-md truncate">
        <?php echo e($m->deskripsi ?? '—'); ?>

    </td>

    <td class="px-4 py-2 text-center">
        <span class="px-3 py-1 text-xs rounded-full
            <?php echo e($m->status === 'aktif' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'); ?>">
            <?php echo e(ucfirst($m->status)); ?>

        </span>
    </td>

    <td class="px-4 py-2 text-center">
        <div class="inline-flex gap-2 justify-center flex-wrap">

            
            <a href="<?php echo e(route('materi.modul.index', $m->id)); ?>"
            class="bg-indigo-100 text-indigo-700 px-3 py-1 rounded text-xs">
                Modul
            </a>

            
            <a href="<?php echo e(route('materi.kompetensi.index', $m->id)); ?>"
            class="bg-green-100 text-green-700 px-3 py-1 rounded text-xs">
                Kompetensi
            </a>

            
            <?php if(! $readonly): ?>
                <button onclick='openEditModal(<?php echo json_encode($m, 15, 512) ?>)'
                    class="bg-yellow-100 text-yellow-700 px-3 py-1 rounded text-xs">
                    Edit
                </button>

                <form action="<?php echo e(route('admin.materi.destroy',$m->id)); ?>"
                    method="POST"
                    onsubmit="return confirmDelete(event)">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button
                        class="bg-red-100 text-red-700 px-3 py-1 rounded text-xs">
                        Hapus
                    </button>
                </form>
            <?php endif; ?>

        </div>
    </td>


</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>

</div>

<?php if(! $readonly): ?>

<script>
function openCreateModal() {
    Swal.fire({
        title: 'Tambah Materi',
        html: materiForm(),
        showConfirmButton: false,
        width: 600,
        footer: actionButtons("<?php echo e(route('admin.materi.store')); ?>", 'POST')
    });
}

function openEditModal(data) {
    Swal.fire({
        title: 'Edit Materi',
        html: materiForm(data),
        showConfirmButton: false,
        width: 600,
        footer: actionButtons(`/materi/${data.id}`, 'PUT')
    });
}

function actionButtons(action, method) {
    return `
    <div class="w-full flex justify-start gap-2">
        <button onclick="handleSubmit('${action}','${method}')"
            class="btn-primary">
            ${method === 'POST' ? 'Simpan' : 'Update'}
        </button>
        <button onclick="Swal.close()" class="btn-secondary">
            Batal
        </button>
    </div>`;
}

function materiForm(data = {}) {
    return `
    <input type="hidden" id="csrf" value="<?php echo e(csrf_token()); ?>">
    <div class="space-y-4 text-left text-sm">
        <div>
            <label class="block mb-1 font-medium">Nama Materi</label>
            <input id="nama_materi"
                class="w-full px-3 py-2 border rounded"
                value="${data.nama_materi ?? ''}">
        </div>
        <div>
            <label class="block mb-1 font-medium">Deskripsi</label>
            <textarea id="deskripsi"
                class="w-full px-3 py-2 border rounded"
                rows="3">${data.deskripsi ?? ''}</textarea>
        </div>
        <div>
            <label class="block mb-1 font-medium">Status</label>
            <select id="status" class="w-full px-3 py-2 border rounded">
                <option value="aktif" ${data.status !== 'nonaktif' ? 'selected' : ''}>Aktif</option>
                <option value="nonaktif" ${data.status === 'nonaktif' ? 'selected' : ''}>Nonaktif</option>
            </select>
        </div>
    </div>`;
}

function handleSubmit(action, method) {
    if (!document.getElementById('nama_materi').value) {
        Swal.showValidationMessage('Nama materi wajib diisi');
        return;
    }
    submitForm(action, method);
}

function submitForm(action, method) {
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = action;
    form.innerHTML = `
        <input type="hidden" name="_token" value="${document.getElementById('csrf').value}">
        ${method !== 'POST' ? `<input type="hidden" name="_method" value="${method}">` : ''}
        <input type="hidden" name="nama_materi" value="${document.getElementById('nama_materi').value}">
        <input type="hidden" name="deskripsi" value="${document.getElementById('deskripsi').value}">
        <input type="hidden" name="status" value="${document.getElementById('status').value}">
    `;
    document.body.appendChild(form);
    form.submit();
}

function confirmDelete(e) {
    e.preventDefault();
    Swal.fire({
        title: 'Hapus materi?',
        text: 'Materi akan dihapus permanen',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, hapus'
    }).then(res => {
        if (res.isConfirmed) e.target.submit();
    });
}
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/admin/materi/index.blade.php ENDPATH**/ ?>