

<?php $__env->startSection('header'); ?>
Edit Home Private
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('home-private.update', $homePrivate->id)); ?>"
      method="POST"
      class="bg-white p-6 rounded shadow space-y-4 max-w-xl">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <?php echo $__env->make('admin.home_private.form', ['homePrivate' => $homePrivate], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="flex gap-2">
        <button class="bg-[#8FBFC2] text-white px-4 py-2 rounded">Update</button>
        <a href="<?php echo e(route('home-private.index')); ?>" class="px-4 py-2">Batal</a>
    </div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/admin/home_private/edit.blade.php ENDPATH**/ ?>