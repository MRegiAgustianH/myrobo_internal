<?php
    $hp = $homePrivate ?? null;
?>

<div>
    <label class="font-medium">Nama Kegiatan</label>
    <input name="nama_kegiatan" class="w-full border rounded px-3 py-2"
           value="<?php echo e(old('nama_kegiatan', $hp->nama_kegiatan ?? '')); ?>">
</div>

<div>
    <label class="font-medium">Nama Siswa</label>
    <input name="nama_peserta" class="w-full border rounded px-3 py-2"
           value="<?php echo e(old('nama_peserta', $hp->nama_peserta ?? '')); ?>">
</div>

<div>
    <label class="font-medium">Nama Wali</label>
    <input name="nama_wali" class="w-full border rounded px-3 py-2"
           value="<?php echo e(old('nama_wali', $hp->nama_wali ?? '')); ?>">
</div>

<div>
    <label class="font-medium">No HP</label>
    <input name="no_hp" class="w-full border rounded px-3 py-2"
           value="<?php echo e(old('no_hp', $hp->no_hp ?? '')); ?>">
</div>

<div>
    <label class="font-medium">Alamat</label>
    <textarea name="alamat" class="w-full border rounded px-3 py-2"><?php echo e(old('alamat', $hp->alamat ?? '')); ?></textarea>
</div>

<div>
    <label class="font-medium">Catatan</label>
    <textarea name="catatan" class="w-full border rounded px-3 py-2"><?php echo e(old('catatan', $hp->catatan ?? '')); ?></textarea>
</div>

<div>
    <label class="font-medium">Status</label>
    <select name="status" class="w-full border rounded px-3 py-2">
        <option value="aktif" <?php echo e(old('status', $hp->status ?? '') === 'aktif' ? 'selected' : ''); ?>>Aktif</option>
        <option value="nonaktif" <?php echo e(old('status', $hp->status ?? '') === 'nonaktif' ? 'selected' : ''); ?>>Nonaktif</option>
    </select>
</div>
<?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/admin/home_private/form.blade.php ENDPATH**/ ?>