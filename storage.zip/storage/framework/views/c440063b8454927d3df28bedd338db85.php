
<div
    x-show="sidebarOpen"
    @click="sidebarOpen = false"
    x-transition.opacity
    class="fixed inset-0 z-30 bg-black/40 md:hidden">
</div>


<aside
    class="fixed md:static inset-y-0 left-0 z-40
           w-64 md:w-56
           min-h-screen
           bg-gradient-to-b from-[#8FBFC2] to-[#7FB3B8]
           transform transition-transform duration-300 ease-out
           -translate-x-full md:translate-x-0
           flex flex-col text-gray-800 shadow-xl"
    :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">

    
    <div class="flex justify-center items-center pt-4 pb-2 shrink-0">
        <img src="<?php echo e(asset('images/applogo.png')); ?>"
            class="h-24 object-contain drop-shadow-sm select-none">
    </div>


    
    <nav
        class="flex-1 px-3 space-y-6 overflow-y-auto text-sm pb-6
               scrollbar-thin scrollbar-thumb-white/40 scrollbar-track-transparent">

    <?php
        $menuClass = 'group flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200';
        $active = 'bg-white text-gray-900 font-semibold shadow';
        $hover  = 'hover:bg-white/80 hover:translate-x-1';
    ?>

    
    <?php if(Auth::user()->isAdmin()): ?>

    <div>
        <p class="text-[11px] uppercase tracking-wider text-gray-700 mb-2 px-3">
            Utama
        </p>

        <a href="<?php echo e(route('dashboard')); ?>"
           class="<?php echo e($menuClass); ?> <?php echo e(request()->routeIs('dashboard') ? $active : $hover); ?>">
            <i data-feather="home" class="w-4 h-4"></i>
            Dashboard
        </a>

        <a href="<?php echo e(route('sekolah.index')); ?>"
           class="<?php echo e($menuClass); ?> mt-1 <?php echo e(request()->routeIs('sekolah.*') ? $active : $hover); ?>">
            <i data-feather="grid" class="w-4 h-4"></i>
            Sekolah
        </a>

        <a href="<?php echo e(route('users.index')); ?>"
           class="<?php echo e($menuClass); ?> mt-1 <?php echo e(request()->routeIs('users.*') ? $active : $hover); ?>">
            <i data-feather="users" class="w-4 h-4"></i>
            User
        </a>

        <a href="<?php echo e(route('home-private.index')); ?>"
           class="<?php echo e($menuClass); ?> mt-1 <?php echo e(request()->routeIs('home-private.*') ? $active : $hover); ?>">
            <i data-feather="globe" class="w-4 h-4"></i>
            Home Private
        </a>
    </div>

    <div>
        <p class="text-[11px] uppercase tracking-wider text-gray-700 mb-2 px-3">
            Penjadwalan
        </p>

        <a href="<?php echo e(route('admin.materi.index')); ?>"
           class="<?php echo e($menuClass); ?> <?php echo e(request()->routeIs('materi.*') ? $active : $hover); ?>">
            <i data-feather="book-open" class="w-4 h-4"></i>
            Materi
        </a>

        <a href="<?php echo e(route('jadwal.index')); ?>"
           class="<?php echo e($menuClass); ?> mt-1 <?php echo e(request()->routeIs('jadwal.*') ? $active : $hover); ?>">
            <i data-feather="calendar" class="w-4 h-4"></i>
            Jadwal
        </a>
    </div>

    <div>
        <p class="text-[11px] uppercase tracking-wider text-gray-700 mb-2 px-3">
            Keuangan
        </p>

        <a href="<?php echo e(route('keuangan.index')); ?>"
           class="<?php echo e($menuClass); ?> <?php echo e(request()->routeIs('keuangan.index') ? $active : $hover); ?>">
            <i data-feather="activity" class="w-4 h-4"></i>
            Pengeluaran
        </a>

        <a href="<?php echo e(route('pembayaran.index')); ?>"
           class="<?php echo e($menuClass); ?> mt-1 <?php echo e(request()->routeIs('pembayaran.index') ? $active : $hover); ?>">
            <i data-feather="credit-card" class="w-4 h-4"></i>
            Pembayaran
        </a>

        <a href="<?php echo e(route('pembayaran.invoice.form')); ?>"
           class="<?php echo e($menuClass); ?> mt-1 <?php echo e(request()->routeIs('pembayaran.invoice.*') ? $active : $hover); ?>">
            <i data-feather="file-text" class="w-4 h-4"></i>
            Cetak Invoice
        </a>
    </div>

    <div>
        <p class="text-[11px] uppercase tracking-wider text-gray-700 mb-2 px-3">
            Laporan
        </p>

        <a href="<?php echo e(route('admin.rapor-tugas.index')); ?>"
           class="<?php echo e($menuClass); ?> <?php echo e(request()->routeIs('admin.rapor-tugas.*') ? $active : $hover); ?>">
            <i data-feather="bar-chart-2" class="w-4 h-4"></i>
            Penugasan Rapor
        </a>

        <a href="<?php echo e(route('absensi.rekap.filter')); ?>"
           class="<?php echo e($menuClass); ?> mt-1 <?php echo e(request()->routeIs('absensi.rekap.*') ? $active : $hover); ?>">
            <i data-feather="clipboard" class="w-4 h-4"></i>
            Rekap Absensi
        </a>

        <a href="<?php echo e(route('pembayaran.rekap')); ?>"
           class="<?php echo e($menuClass); ?> mt-1 <?php echo e(request()->routeIs('pembayaran.rekap') ? $active : $hover); ?>">
            <i data-feather="dollar-sign" class="w-4 h-4"></i>
            Rekap Pembayaran
        </a>
    </div>

    <?php endif; ?>

    
    <?php if(Auth::user()->role === 'instruktur'): ?>

    <div>
        <p class="text-[11px] uppercase tracking-wider text-gray-600 mb-2 px-3">
            Instruktur
        </p>

        <a href="<?php echo e(route('dashboard')); ?>"
           class="<?php echo e($menuClass); ?> <?php echo e(request()->routeIs('dashboard.instruktur') ? $active : $hover); ?>">
            <i data-feather="home" class="w-4 h-4"></i>
            Dashboard
        </a>

        <a href="<?php echo e(route('jadwal.index')); ?>"
           class="<?php echo e($menuClass); ?> mt-1 <?php echo e(request()->routeIs('jadwal.*') ? $active : $hover); ?>">
            <i data-feather="calendar" class="w-4 h-4"></i>
            Jadwal Saya
        </a>

        <a href="<?php echo e(route('admin.materi.index')); ?>"
           class="<?php echo e($menuClass); ?> mt-1 <?php echo e(request()->routeIs('materi.*') ? $active : $hover); ?>">
            <i data-feather="book-open" class="w-4 h-4"></i>
            Materi & Modul
        </a>

        <a href="<?php echo e(route('instruktur.rapor-tugas.index')); ?>"
           class="<?php echo e($menuClass); ?> mt-1 <?php echo e(request()->routeIs('instruktur.rapor-tugas.*') ? $active : $hover); ?>">
            <i data-feather="file-text" class="w-4 h-4"></i>
            Tugas Rapor
        </a>
    </div>

    <?php endif; ?>

    
    <?php if(Auth::user()->isAdminSekolah()): ?>

    <div>
        <p class="text-[11px] uppercase tracking-wider text-gray-700 mb-2 px-3">
            Admin Sekolah
        </p>

        <a href="<?php echo e(route('dashboard')); ?>"
           class="<?php echo e($menuClass); ?> <?php echo e(request()->routeIs('dashboard.admin_sekolah') ? $active : $hover); ?>">
            <i data-feather="home" class="w-4 h-4"></i>
            Dashboard
        </a>

        <a href="<?php echo e(route('absensi.rekap.filter')); ?>"
           class="<?php echo e($menuClass); ?> mt-1 <?php echo e(request()->routeIs('absensi.rekap.*') ? $active : $hover); ?>">
            <i data-feather="clipboard" class="w-4 h-4"></i>
            Rekap Absensi
        </a>

        <a href="<?php echo e(route('pembayaran.rekap')); ?>"
           class="<?php echo e($menuClass); ?> mt-1 <?php echo e(request()->routeIs('pembayaran.rekap') ? $active : $hover); ?>">
            <i data-feather="dollar-sign" class="w-4 h-4"></i>
            Rekap Pembayaran
        </a>
    </div>

    <?php endif; ?>

    
    <?php if(Auth::user()->role === 'bendahara'): ?>

    <div>
        <p class="text-[11px] uppercase tracking-wider text-gray-700 mb-2 px-3">
            Bendahara
        </p>

        <a href="<?php echo e(route('dashboard')); ?>"
           class="<?php echo e($menuClass); ?> <?php echo e(request()->routeIs('dashboard') ? $active : $hover); ?>">
            <i data-feather="home" class="w-4 h-4"></i>
            Dashboard
        </a>
    </div>

    <div>
        <p class="text-[11px] uppercase tracking-wider text-gray-700 mb-2 px-3">
            Keuangan
        </p>

        <a href="<?php echo e(route('keuangan.index')); ?>"
           class="<?php echo e($menuClass); ?> <?php echo e(request()->routeIs('keuangan.index') ? $active : $hover); ?>">
            <i data-feather="activity" class="w-4 h-4"></i>
            Pengeluaran
        </a>

        <a href="<?php echo e(route('pembayaran.index')); ?>"
           class="<?php echo e($menuClass); ?> mt-1 <?php echo e(request()->routeIs('pembayaran.index') ? $active : $hover); ?>">
            <i data-feather="credit-card" class="w-4 h-4"></i>
            Pembayaran
        </a>

        <a href="<?php echo e(route('pembayaran.invoice.form')); ?>"
           class="<?php echo e($menuClass); ?> mt-1 <?php echo e(request()->routeIs('pembayaran.invoice.*') ? $active : $hover); ?>">
            <i data-feather="file-text" class="w-4 h-4"></i>
            Cetak Invoice
        </a>
        
        <a href="<?php echo e(route('pembayaran.rekap')); ?>"
           class="<?php echo e($menuClass); ?> mt-1 <?php echo e(request()->routeIs('pembayaran.rekap') ? $active : $hover); ?>">
            <i data-feather="dollar-sign" class="w-4 h-4"></i>
            Rekap Pembayaran
        </a>
    </div>

    <?php endif; ?>

    
    <?php if(Auth::user()->role === 'sekretaris'): ?>

    <div>
        <p class="text-[11px] uppercase tracking-wider text-gray-700 mb-2 px-3">
            Sekretaris
        </p>

        <a href="<?php echo e(route('dashboard')); ?>"
           class="<?php echo e($menuClass); ?> <?php echo e(request()->routeIs('dashboard') ? $active : $hover); ?>">
            <i data-feather="home" class="w-4 h-4"></i>
            Dashboard
        </a>
    </div>

    <div>
        <p class="text-[11px] uppercase tracking-wider text-gray-700 mb-2 px-3">
            Akademik
        </p>

        <a href="<?php echo e(route('admin.rapor-tugas.index')); ?>"
           class="<?php echo e($menuClass); ?> <?php echo e(request()->routeIs('admin.rapor-tugas.*') ? $active : $hover); ?>">
            <i data-feather="bar-chart-2" class="w-4 h-4"></i>
            Penugasan Rapor
        </a>
        
        <a href="<?php echo e(route('jadwal.index')); ?>"
           class="<?php echo e($menuClass); ?> mt-1 <?php echo e(request()->routeIs('jadwal.*') ? $active : $hover); ?>">
            <i data-feather="calendar" class="w-4 h-4"></i>
            Jadwal
        </a>

        <a href="<?php echo e(route('absensi.rekap.filter')); ?>"
           class="<?php echo e($menuClass); ?> mt-1 <?php echo e(request()->routeIs('absensi.rekap.*') ? $active : $hover); ?>">
            <i data-feather="clipboard" class="w-4 h-4"></i>
            Rekap Absensi
        </a>
    </div>

    <?php endif; ?>

    </nav>

    
    <div class="border-t border-white/40 p-4 text-xs shrink-0">

        <div class="flex items-center gap-3 mb-4">
            <div
                class="w-10 h-10 rounded-full bg-white text-gray-900
                       flex items-center justify-center shadow">
                <i data-feather="user" class="w-4 h-4"></i>
            </div>

            <div class="leading-tight overflow-hidden">
                <p class="font-semibold truncate">
                    <?php echo e(Auth::user()->name); ?>

                </p>
                <p class="text-[11px] capitalize text-gray-600">
                    <?php echo e(Auth::user()->role); ?>

                </p>
            </div>
        </div>

        <a href="<?php echo e(route('profile.edit')); ?>"
           class="group flex items-center gap-3 px-3 py-2 rounded-xl
                  hover:bg-white/80 transition">
            <i data-feather="settings" class="w-4 h-4"></i>
            Profil
        </a>

        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button
                class="w-full group flex items-center gap-3 px-3 py-2 mt-1 rounded-xl
                       hover:bg-white/80 transition">
                <i data-feather="log-out" class="w-4 h-4"></i>
                Logout
            </button>
        </form>
    </div>

</aside>
<?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>