<?php $__env->startSection('header'); ?>
Rekap Pembayaran
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<?php $jenis = request('jenis_peserta'); ?>

<form method="GET"
      class="bg-[#F6FAFB] border border-[#E3EEF0]
             rounded-2xl shadow-sm mb-6 p-5">

    <div class="grid grid-cols-1 md:grid-cols-5 gap-4 items-end">

        
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">
                Jenis Peserta
            </label>
            <select name="jenis_peserta"
                    id="jenisPeserta"
                    class="w-full bg-white border border-[#E3EEF0]
                           rounded-lg px-3 py-2 text-sm">
                <option value="">Semua</option>
                <option value="sekolah" <?php echo e($jenis === 'sekolah' ? 'selected' : ''); ?>>
                    Sekolah
                </option>
                <option value="home_private" <?php echo e($jenis === 'home_private' ? 'selected' : ''); ?>>
                    Home Private
                </option>
            </select>
        </div>

        
        <div id="filterSekolah" class="<?php echo e($jenis === 'home_private' ? 'hidden' : ''); ?>">
            <label class="block text-sm font-medium text-gray-700 mb-1">
                Sekolah
            </label>

            <?php if(auth()->user()->isAdmin() || auth()->user()->role === 'bendahara'): ?>
                <select name="sekolah_id"
                        class="w-full bg-white border border-[#E3EEF0]
                               rounded-lg px-3 py-2 text-sm">
                    <option value="">-- Semua Sekolah --</option>
                    <?php $__currentLoopData = $sekolahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s->id); ?>"
                            <?php echo e((string)$sekolahId === (string)$s->id ? 'selected' : ''); ?>>
                            <?php echo e($s->nama_sekolah); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <?php else: ?>
                <input type="hidden" name="sekolah_id" value="<?php echo e(auth()->user()->sekolah_id); ?>">
                <div class="px-3 py-2 bg-white border border-[#E3EEF0]
                            rounded-lg text-sm text-gray-700">
                    <?php echo e(auth()->user()->sekolah->nama_sekolah); ?>

                </div>
            <?php endif; ?>
        </div>

        
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Bulan</label>
            <select name="bulan"
                    class="w-full bg-white border border-[#E3EEF0]
                           rounded-lg px-3 py-2 text-sm">
                <?php for($i=1;$i<=12;$i++): ?>
                    <option value="<?php echo e($i); ?>" <?php echo e((int)$bulan === $i ? 'selected' : ''); ?>>
                        <?php echo e(\Carbon\Carbon::create()->month($i)->translatedFormat('F')); ?>

                    </option>
                <?php endfor; ?>
            </select>
        </div>

        
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Tahun</label>
            <input type="number" name="tahun"
                   value="<?php echo e($tahun); ?>"
                   class="w-full bg-white border border-[#E3EEF0]
                          rounded-lg px-3 py-2 text-sm">
        </div>

        
        <div class="flex gap-2">
            <button class="flex-1 bg-[#8FBFC2] hover:bg-[#6FA9AD]
                           text-gray-900 px-4 py-2 rounded-lg">
                Tampilkan
            </button>
            <a href="<?php echo e(url()->current()); ?>"
               class="flex-1 bg-white border border-[#E3EEF0]
                      px-4 py-2 rounded-lg text-center text-sm">
                Reset
            </a>
        </div>

    </div>
</form>


<?php if($bulan && $tahun): ?>
<form method="GET"
      action="<?php echo e(route('pembayaran.rekap.export-pdf')); ?>"
      target="_blank"
      class="mb-4">

    <input type="hidden" name="bulan" value="<?php echo e($bulan); ?>">
    <input type="hidden" name="tahun" value="<?php echo e($tahun); ?>">

    <?php if(!empty(request('jenis_peserta'))): ?>
        <input type="hidden" name="jenis_peserta" value="<?php echo e(request('jenis_peserta')); ?>">
    <?php endif; ?>

    <?php if(!empty($sekolahId)): ?>
        <input type="hidden" name="sekolah_id" value="<?php echo e($sekolahId); ?>">
    <?php endif; ?>

    <button
        class="inline-flex items-center gap-2
               bg-white border border-[#E3EEF0]
               hover:bg-[#F6FAFB]
               px-4 py-2 rounded-lg
               text-sm font-medium">
        <i data-feather="file-text" class="w-4 h-4"></i>
        Export Rekap PDF
    </button>
</form>
<?php endif; ?>


<div class="mt-4 mb-4 text-center font-semibold text-gray-800">
    Total Lunas:
    <span class="block sm:inline text-gray-900">
        Rp <?php echo e(number_format($totalLunas,0,',','.')); ?>

    </span>
</div>


<div class="space-y-4 md:hidden">

<?php $__empty_1 = true; $__currentLoopData = $pembayarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<?php
    $namaPeserta = $p->jenis_peserta === 'home_private'
        ? $p->homePrivate?->nama_peserta
        : $p->peserta?->nama;

    $namaSekolah = $p->jenis_peserta === 'home_private'
        ? 'Home Private'
        : ($p->sekolah?->nama_sekolah ?? '-');
?>

<div class="border rounded-xl p-4 shadow-sm text-sm
            <?php echo e($p->status === 'belum' ? 'bg-red-50/70' : 'bg-white'); ?>">

    <div class="font-semibold text-gray-800">
        <?php echo e($namaPeserta ?? '-'); ?>

    </div>

    <div class="text-xs text-gray-600 mt-1">
        <?php echo e($namaSekolah); ?>

    </div>

    <div class="mt-2 text-xs">
        Tanggal:
        <span class="font-medium">
            <?php echo e($p->tanggal_bayar?->format('d/m/Y') ?? '-'); ?>

        </span>
    </div>

    <div class="mt-2 font-semibold">
        Rp <?php echo e(number_format($p->jumlah ?? 0,0,',','.')); ?>

    </div>

    <div class="mt-3">
        <span class="px-2 py-1 rounded-full text-xs font-semibold
            <?php echo e($p->status === 'lunas'
                ? 'bg-green-100 text-green-700'
                : 'bg-red-100 text-red-700'); ?>">
            <?php echo e(strtoupper($p->status)); ?>

        </span>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<div class="text-center text-gray-500 py-6">
    Tidak ada data pembayaran
</div>
<?php endif; ?>

</div>



<div class="hidden md:block bg-white border border-[#E3EEF0]
            rounded-2xl shadow-sm overflow-x-auto">

<table class="min-w-full text-sm">
<thead class="bg-[#F6FAFB] border-b border-[#E3EEF0]">
<tr>
    <th class="px-3 py-2">No</th>
    <th class="px-3 py-2 text-left">Peserta</th>
    <th class="px-3 py-2">Jenis</th>
    <th class="px-3 py-2">Sekolah</th>
    <th class="px-3 py-2 text-center">Tanggal</th>
    <th class="px-3 py-2 text-right">Jumlah</th>
    <th class="px-3 py-2 text-center">Status</th>
</tr>
</thead>

<tbody class="divide-y divide-[#E3EEF0]">
<?php $__currentLoopData = $pembayarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
    $namaPeserta = $p->jenis_peserta === 'home_private'
        ? $p->homePrivate?->nama_peserta
        : $p->peserta?->nama;

    $namaSekolah = $p->jenis_peserta === 'home_private'
        ? 'Home Private'
        : ($p->sekolah?->nama_sekolah ?? '-');
?>

<tr class="<?php echo e($p->status === 'belum' ? 'bg-red-50/60' : ''); ?>">
    <td class="px-3 py-2"><?php echo e($i+1); ?></td>
    <td class="px-3 py-2 font-medium"><?php echo e($namaPeserta ?? '-'); ?></td>
    <td class="px-3 py-2 capitalize"><?php echo e(str_replace('_',' ',$p->jenis_peserta)); ?></td>
    <td class="px-3 py-2"><?php echo e($namaSekolah); ?></td>
    <td class="px-3 py-2 text-center">
        <?php echo e($p->tanggal_bayar?->format('d/m/Y') ?? '-'); ?>

    </td>
    <td class="px-3 py-2 text-right font-medium">
        Rp <?php echo e(number_format($p->jumlah ?? 0,0,',','.')); ?>

    </td>
    <td class="px-3 py-2 text-center">
        <span class="px-2 py-1 rounded-full text-xs font-semibold
            <?php echo e($p->status === 'lunas'
                ? 'bg-green-100 text-green-700'
                : 'bg-red-100 text-red-700'); ?>">
            <?php echo e(strtoupper($p->status)); ?>

        </span>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>




<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script>
document.getElementById('jenisPeserta')?.addEventListener('change', function () {
    const sekolah = document.getElementById('filterSekolah');
    if (this.value === 'home_private') {
        sekolah.classList.add('hidden');
    } else {
        sekolah.classList.remove('hidden');
    }
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/pembayaran/rekap.blade.php ENDPATH**/ ?>