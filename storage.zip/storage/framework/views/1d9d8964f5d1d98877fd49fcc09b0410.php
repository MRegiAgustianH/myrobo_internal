

<?php $__env->startSection('header'); ?>
Edit Rapor
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('rapor.update', $rapor->id)); ?>"
      method="POST" class="space-y-6">
<?php echo csrf_field(); ?>
<?php echo method_field('PATCH'); ?>

<?php echo $__env->make('admin.rapor._form', ['rapor' => $rapor], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="flex justify-end">
    <button class="bg-indigo-600 text-white px-6 py-2 rounded">
        Update Rapor
    </button>
</div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/admin/rapor/edit.blade.php ENDPATH**/ ?>