

<?php $__env->startSection('header'); ?>
Manajemen Rapor
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="mb-4 p-3 rounded bg-green-100 text-green-700">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>


<div class="mb-4 flex justify-between items-center">
    <div class="text-sm text-gray-600">
        Form Input Rapor
    </div>

    <a href="<?php echo e(route('kompetensi.index')); ?>"
       class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded text-sm">
        Kelola Kompetensi
    </a>
</div>


<div class="bg-white rounded-lg shadow p-6">

    <form id="raporForm" action="<?php echo e(route('rapor.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">

            
            <div>
                <label class="block text-sm font-medium mb-1">Sekolah</label>
                <select id="sekolah_id"
                        name="sekolah_id"
                        class="w-full border rounded px-3 py-2 text-sm"
                        required>
                    <option value="">-- Pilih Sekolah --</option>
                    <?php $__currentLoopData = $sekolahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s->id); ?>"><?php echo e($s->nama_sekolah); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div>
                <label class="block text-sm font-medium mb-1">Peserta</label>
                <select name="peserta_id"
                        id="peserta_id"
                        class="w-full border rounded px-3 py-2 text-sm"
                        required
                        disabled
                        onchange="setKelas(this)">
                    <option value="">-- Pilih Peserta --</option>
                </select>
            </div>


            
            <div>
                <label class="block text-sm font-medium mb-1">Semester</label>
                <select name="semester_id"
                        id="semester_id"
                        class="w-full border rounded px-3 py-2 text-sm"
                        required
                        onchange="setTahunAjaran(this)">
                    <option value="">-- Pilih Semester --</option>
                    <?php $__currentLoopData = $semesters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s->id); ?>">
                            <?php echo e($s->nama_semester); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

        </div>

        
        <div class="mb-6">
            <label class="block text-sm font-medium mb-1">Tahun Ajaran</label>
            <input type="text"
                   id="tahun_ajaran"
                   class="w-full md:w-1/3 border rounded px-3 py-2 text-sm bg-gray-100"
                   readonly>
        </div>

        
        <div class="mb-6">
            <label class="block text-sm font-medium mb-1">Kelas</label>
            <input type="text"
                id="nama_kelas"
                class="w-full md:w-1/3 border rounded px-3 py-2 text-sm bg-gray-100"
                readonly>
        </div>


        
        <div class="mb-6">
            <label class="block text-sm font-medium mb-1">Nilai Keseluruhan</label>
            <select name="nilai_akhir"
                    class="w-full md:w-1/3 border rounded px-3 py-2 text-sm"
                    required>
                <option value="">-- Pilih Nilai --</option>
                <option value="A">A (Sangat Baik)</option>
                <option value="B">B (Baik)</option>
                <option value="C">C (Cukup)</option>
            </select>
        </div>

        
        <div class="mb-6">
            <label class="block text-sm font-medium mb-1">Materi yang Diajarkan</label>
            <textarea name="materi"
                      rows="4"
                      class="w-full border rounded px-3 py-2 text-sm"
                      placeholder="Tuliskan materi yang diajarkan selama semester ini..."
                      required></textarea>
        </div>

        
        <div class="space-y-8">
        <?php $__currentLoopData = $kompetensis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="border rounded-lg p-4">
                <h4 class="font-semibold mb-3 text-gray-700">
                    <?php echo e($k->nama_kompetensi); ?>

                </h4>

                <table class="w-full text-sm border-collapse border">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="border px-2 py-2 text-left">Indikator</th>
                            <th class="border px-2 py-2 text-center">Cukup</th>
                            <th class="border px-2 py-2 text-center">Baik</th>
                            <th class="border px-2 py-2 text-center">Sangat Baik</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $k->indikatorKompetensis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="border px-2 py-2">
                                <?php echo e($i->nama_indikator); ?>

                            </td>

                            <?php $__currentLoopData = ['cukup','baik','sangat_baik']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="border px-2 py-2 text-center">
                                <input type="radio"
                                    name="nilai[<?php echo e($i->id); ?>]"
                                    value="<?php echo e($n); ?>"
                                    required>
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div class="mt-6">
            <label class="block text-sm font-medium mb-1">Kesimpulan</label>
            <textarea name="kesimpulan"
                      rows="4"
                      class="w-full border rounded px-3 py-2 text-sm"
                      placeholder="Tuliskan kesimpulan penilaian..."></textarea>
        </div>

        
        <div class="mt-6 md:w-1/3">
            <label class="block text-sm font-medium mb-1">Nama Penilai / TTD</label>
            <input type="text"
                name="ttd_nama"
                class="w-full border rounded px-3 py-2 text-sm"
                placeholder="Nama guru / pembina"
                required>
        </div>


        
        <div class="mt-6 flex justify-end">
            <button type="submit"
                    class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded text-sm">
                Simpan Rapor
            </button>
        </div>

    </form>
</div>

<script>
document.getElementById('sekolah_id').addEventListener('change', function () {
    const sekolahId = this.value;
    const pesertaSelect = document.getElementById('peserta_id');

    if (!sekolahId) {
        pesertaSelect.innerHTML = '<option value="">-- Pilih Peserta --</option>';
        pesertaSelect.disabled = true;
        return;
    }

    pesertaSelect.innerHTML = '<option>Memuat...</option>';
    pesertaSelect.disabled = true;

    fetch(`/rapor/peserta-by-sekolah/${sekolahId}`)
        .then(res => {
            if (!res.ok) throw new Error('Gagal memuat peserta');
            return res.json();
        })
        .then(data => {
            let options = '<option value="">-- Pilih Peserta --</option>';

            if (data.length === 0) {
                options = '<option value="">Tidak ada peserta</option>';
            }

            data.forEach(p => {
                options += `
                    <option value="${p.id}" data-kelas="${p.kelas}">
                        ${p.nama}
                    </option>`;
            });

            pesertaSelect.innerHTML = options;
            pesertaSelect.disabled = false;
        })
        .catch(err => {
            console.error(err);
            pesertaSelect.innerHTML = '<option>Gagal memuat data</option>';
        });
});

function setKelas(select) {
    const kelas = select.options[select.selectedIndex]?.getAttribute('data-kelas');
    document.getElementById('nama_kelas').value = kelas || '';
}
</script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/rapor/index.blade.php ENDPATH**/ ?>