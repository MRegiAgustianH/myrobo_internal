

<?php $__env->startSection('header'); ?>
Verifikasi Rapor
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<?php if(session('success')): ?>
    <div class="mb-4 p-3 bg-green-100 text-green-700 rounded text-sm">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="mb-4 p-3 bg-red-100 text-red-700 rounded text-sm">
        <?php echo e($errors->first()); ?>

    </div>
<?php endif; ?>


<div class="bg-white rounded-2xl shadow p-6 mb-6">

    <h2 class="text-base font-semibold text-gray-800 mb-4">
        Informasi Rapor
    </h2>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">

        <div>
            <p class="text-gray-500">Peserta</p>
            <p class="font-medium"><?php echo e($rapor->peserta->nama); ?></p>
        </div>

        <div>
            <p class="text-gray-500">Sekolah</p>
            <p class="font-medium"><?php echo e($rapor->sekolah->nama_sekolah); ?></p>
        </div>

        <div>
            <p class="text-gray-500">Semester</p>
            <p class="font-medium"><?php echo e($rapor->semester->nama_semester); ?></p>
        </div>

        <div>
            <p class="text-gray-500">Status</p>
            <span class="inline-block px-3 py-1 text-xs rounded
                <?php echo e($rapor->status === 'approved'
                    ? 'bg-green-100 text-green-700'
                    : ($rapor->status === 'revision'
                        ? 'bg-red-100 text-red-700'
                        : 'bg-yellow-100 text-yellow-700')); ?>">
                <?php echo e(ucfirst($rapor->status)); ?>

            </span>
        </div>

        <div class="md:col-span-2">
            <p class="text-gray-500">Materi Rapor</p>
            <p class="font-medium"><?php echo e($rapor->materi); ?></p>
        </div>

        <div>
            <p class="text-gray-500">Nilai Akhir</p>
            <p class="font-bold text-lg"><?php echo e($rapor->nilai_akhir); ?></p>
        </div>

        <?php if($rapor->kesimpulan): ?>
        <div class="md:col-span-2">
            <p class="text-gray-500">Kesimpulan</p>
            <p class="text-sm"><?php echo e($rapor->kesimpulan); ?></p>
        </div>
        <?php endif; ?>
    </div>
</div>


<div class="bg-white rounded-2xl shadow p-6 mb-6">

    <h3 class="font-semibold text-gray-800 mb-4">
        Detail Penilaian
    </h3>

    <?php $__currentLoopData = $rapor->nilaiRapors->groupBy('indikatorKompetensi.kompetensi.nama_kompetensi'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kompetensi => $nilais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="mb-5">
            <p class="font-medium text-gray-700 mb-2">
                <?php echo e($kompetensi); ?>

            </p>

            <div class="space-y-2 text-sm">
                <?php $__currentLoopData = $nilais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex justify-between items-center border-b pb-1">
                        <span>
                            <?php echo e($nilai->indikatorKompetensi->nama_indikator); ?>

                        </span>
                        <span class="font-semibold">
                            <?php echo e($nilai->nilai); ?>

                        </span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<div class="bg-white rounded-2xl shadow p-6">

    <h3 class="font-semibold text-gray-800 mb-4">
        Aksi Admin
    </h3>

    <div class="flex flex-col md:flex-row gap-4">

        
        <form method="POST"
              action="<?php echo e(route('admin.rapor.verifikasi.approve', $rapor->id)); ?>">
            <?php echo csrf_field(); ?>
            <button
                class="w-full md:w-auto bg-green-600 hover:bg-green-700
                       text-white px-6 py-2 rounded-lg text-sm">
                Setujui Rapor
            </button>
        </form>

        
        <form method="POST"
              action="<?php echo e(route('admin.rapor.verifikasi.revision', $rapor->id)); ?>"
              class="flex-1">
            <?php echo csrf_field(); ?>

            <textarea
                name="catatan_revisi"
                rows="2"
                placeholder="Catatan revisi untuk instruktur"
                class="w-full border rounded px-3 py-2 text-sm mb-2"
                required></textarea>

            <button
                class="w-full bg-red-600 hover:bg-red-700
                       text-white px-6 py-2 rounded-lg text-sm">
                Minta Revisi
            </button>
        </form>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/admin/rapor/verifikasi.blade.php ENDPATH**/ ?>