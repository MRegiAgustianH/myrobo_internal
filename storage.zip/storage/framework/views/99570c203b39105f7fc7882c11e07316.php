<?php $__env->startSection('header'); ?>
Pembayaran Bulanan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<?php if(session('success')): ?>
<div class="mb-4 p-3 rounded-lg bg-green-100 text-green-700 border border-green-200">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php
    $showSekolah     = request('jenis_peserta') !== 'home_private';
    $showHomePrivate = request('jenis_peserta') !== 'sekolah';
?>


<form method="GET"
      class="bg-[#F6FAFB] border border-[#E3EEF0]
             rounded-2xl shadow-sm mb-6 p-5">

<?php
    $jenis = request('jenis_peserta');
?>

<div class="grid grid-cols-1 md:grid-cols-6 gap-4 items-end">

    
    <div>
        <label class="block text-sm font-medium mb-1">
            Jenis Peserta
        </label>
        <select name="jenis_peserta"
                id="jenisPeserta"
                class="w-full border rounded-lg px-3 py-2 text-sm">
            <option value="">Semua</option>
            <option value="sekolah" <?php echo e($jenis === 'sekolah' ? 'selected' : ''); ?>>
                Sekolah
            </option>
            <option value="home_private" <?php echo e($jenis === 'home_private' ? 'selected' : ''); ?>>
                Home Private
            </option>
        </select>
    </div>

    
    <div id="filterSekolah"
         class="<?php echo e($jenis === 'home_private' ? 'hidden' : ''); ?>">
        <label class="block text-sm font-medium mb-1">
            Sekolah
        </label>

        <select name="sekolah_id"
                class="w-full border rounded-lg px-3 py-2 text-sm">
            <option value="">Semua Sekolah</option>
            <?php $__currentLoopData = $sekolahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($s->id); ?>"
                    <?php echo e((string)$sekolahId === (string)$s->id ? 'selected' : ''); ?>>
                    <?php echo e($s->nama_sekolah); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    
    <div>
        <label class="block text-sm font-medium mb-1">Bulan</label>
        <select name="bulan"
                class="w-full border rounded-lg px-3 py-2 text-sm">
            <?php for($i=1;$i<=12;$i++): ?>
                <option value="<?php echo e($i); ?>" <?php echo e((int)$bulan === $i ? 'selected' : ''); ?>>
                    <?php echo e(\Carbon\Carbon::create()->month($i)->translatedFormat('F')); ?>

                </option>
            <?php endfor; ?>
        </select>
    </div>

    
    <div>
        <label class="block text-sm font-medium mb-1">Tahun</label>
        <input type="number"
               name="tahun"
               value="<?php echo e($tahun); ?>"
               class="w-full border rounded-lg px-3 py-2 text-sm">
    </div>

    
    <div class="md:col-span-2 flex gap-2">
        <button
            class="flex-1 bg-[#8FBFC2] rounded-lg py-2 font-medium">
            Tampilkan
        </button>

        <a href="<?php echo e(url()->current()); ?>"
           class="flex-1 border rounded-lg py-2 text-center text-sm">
            Reset
        </a>
    </div>

</div>
</form>


<form action="<?php echo e(route('pembayaran.store')); ?>" method="POST">
<?php echo csrf_field(); ?>


<div class="space-y-4 md:hidden">


<?php if($showSekolah): ?>
<?php $__currentLoopData = $pesertaSekolah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $pay = $pembayaranMap['sekolah_'.$p->id] ?? null; ?>
<div class="bg-white border rounded-xl p-4 shadow-sm">
    <div class="font-semibold"><?php echo e($p->nama); ?></div>
    <div class="text-xs text-blue-700 mb-3">Sekolah</div>

    <div class="flex justify-between items-center">
        <input type="number" 
               name="pembayaran[<?php echo e($p->id); ?>][jumlah]"
               value="<?php echo e($pay ? $pay->jumlah : ($p->sekolah->nominal_pembayaran ?? 150000)); ?>" 
               class="border rounded px-2 py-1 text-sm w-32 pay-amount"
               <?php echo e($pay?->status !== 'lunas' ? 'disabled' : ''); ?>>
        <input type="checkbox"
            name="pembayaran[<?php echo e($p->id); ?>][status]"
            class="pay-check"
            <?php echo e($pay?->status === 'lunas' ? 'checked' : ''); ?>>
    </div>

    <input type="hidden" name="pembayaran[<?php echo e($p->id); ?>][jenis]" value="sekolah">
    <input type="hidden" name="pembayaran[<?php echo e($p->id); ?>][sekolah_id]" value="<?php echo e($p->sekolah_id); ?>">

    <input type="date"
        name="pembayaran[<?php echo e($p->id); ?>][tanggal_bayar]"
        value="<?php echo e($pay?->tanggal_bayar?->format('Y-m-d')); ?>"
        class="w-full mt-3 border rounded px-3 py-2 text-sm"
        <?php echo e($pay?->status !== 'lunas' ? 'disabled' : ''); ?>>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


<?php if($showHomePrivate): ?>
<?php $__currentLoopData = $homePrivates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $pay = $pembayaranMap['home_'.$hp->id] ?? null; ?>
<div class="bg-[#FAFAFA] border rounded-xl p-4 shadow-sm">
    <div class="font-semibold"><?php echo e($hp->nama_peserta); ?></div>
    <div class="text-xs text-purple-700 mb-3">Home Private</div>

    <div class="flex justify-between items-center">
        <input type="number"
               name="pembayaran[<?php echo e($hp->id); ?>][jumlah]"
               value="<?php echo e($pay ? $pay->jumlah : 450000); ?>"
               class="border rounded px-2 py-1 text-sm w-32 pay-amount"
               <?php echo e($pay?->status !== 'lunas' ? 'disabled' : ''); ?>>
        <input type="checkbox"
            name="pembayaran[<?php echo e($hp->id); ?>][status]"
            class="pay-check"
            <?php echo e($pay?->status === 'lunas' ? 'checked' : ''); ?>>
    </div>

    <input type="hidden" name="pembayaran[<?php echo e($hp->id); ?>][jenis]" value="home_private">

    <input type="date"
        name="pembayaran[<?php echo e($hp->id); ?>][tanggal_bayar]"
        value="<?php echo e($pay?->tanggal_bayar?->format('Y-m-d')); ?>"
        class="w-full mt-3 border rounded px-3 py-2 text-sm"
        <?php echo e($pay?->status !== 'lunas' ? 'disabled' : ''); ?>>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</div>


<div class="hidden md:block bg-white border rounded-2xl shadow-sm overflow-x-auto">
<table class="min-w-full text-sm">
<thead class="bg-[#F6FAFB] border-b">
<tr>
    <th class="px-4 py-2">No</th>
    <th class="px-4 py-2 text-left">Peserta</th>
    <th class="px-4 py-2">Jenis</th>
    <th class="px-4 py-2 text-center">Lunas</th>
    <th class="px-4 py-2 text-center">Nominal</th>
    <th class="px-4 py-2 text-center">Tanggal</th>
</tr>
</thead>

<tbody class="divide-y">

<?php if($showSekolah): ?>
<?php $__currentLoopData = $pesertaSekolah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $pay = $pembayaranMap['sekolah_'.$p->id] ?? null; ?>
<tr>
    <td class="px-4 py-2"><?php echo e($i+1); ?></td>
    <td class="px-4 py-2"><?php echo e($p->nama); ?></td>
    <td class="px-4 py-2">Sekolah</td>
    <td class="text-center">
        <input type="checkbox"
            name="pembayaran[<?php echo e($p->id); ?>][status]"
            class="pay-check"
            <?php echo e($pay?->status === 'lunas' ? 'checked' : ''); ?>>
    </td>
    <td class="text-center">
        <input type="number"
               name="pembayaran[<?php echo e($p->id); ?>][jumlah]"
               value="<?php echo e($pay ? $pay->jumlah : ($p->sekolah->nominal_pembayaran ?? 150000)); ?>"
               class="border rounded px-2 py-1 text-sm w-24 text-center pay-amount"
               <?php echo e($pay?->status !== 'lunas' ? 'disabled' : ''); ?>>
    </td>
    <td class="text-center">
        <input type="date"
            name="pembayaran[<?php echo e($p->id); ?>][tanggal_bayar]"
            value="<?php echo e($pay?->tanggal_bayar?->format('Y-m-d')); ?>"
            class="border rounded px-2 py-1 text-sm"
            <?php echo e($pay?->status !== 'lunas' ? 'disabled' : ''); ?>>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if($showHomePrivate): ?>
<?php $__currentLoopData = $homePrivates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $pay = $pembayaranMap['home_'.$hp->id] ?? null; ?>
<tr class="bg-gray-50">
    <td class="px-4 py-2">–</td>
    <td class="px-4 py-2"><?php echo e($hp->nama_peserta); ?></td>
    <td class="px-4 py-2">Home Private</td>
    <td class="text-center">
        <input type="checkbox"
            name="pembayaran[<?php echo e($hp->id); ?>][status]"
            class="pay-check"
            <?php echo e($pay?->status === 'lunas' ? 'checked' : ''); ?>>
    </td>
    <td class="text-center">
        <input type="number"
               name="pembayaran[<?php echo e($hp->id); ?>][jumlah]"
               value="<?php echo e($pay ? $pay->jumlah : 450000); ?>"
               class="border rounded px-2 py-1 text-sm w-24 text-center pay-amount"
               <?php echo e($pay?->status !== 'lunas' ? 'disabled' : ''); ?>>
    </td>
    <td class="text-center">
        <input type="date"
            name="pembayaran[<?php echo e($hp->id); ?>][tanggal_bayar]"
            value="<?php echo e($pay?->tanggal_bayar?->format('Y-m-d')); ?>"
            class="border rounded px-2 py-1 text-sm"
            <?php echo e($pay?->status !== 'lunas' ? 'disabled' : ''); ?>>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

</tbody>
</table>
</div>

<input type="hidden" name="bulan" value="<?php echo e($bulan); ?>">
<input type="hidden" name="tahun" value="<?php echo e($tahun); ?>">

<div class="mt-6 text-right">
    <button class="bg-[#8FBFC2] px-6 py-2 rounded-xl font-semibold">
        Simpan Pembayaran
    </button>
</div>

</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.querySelectorAll('.pay-check').forEach(cb => {
    cb.addEventListener('change', function () {
        const box = this.closest('tr') || this.closest('.shadow-sm');
        const date = box.querySelector('input[type=date]');
        if (!date) return;

        const amount = box.querySelector('.pay-amount');

        if (this.checked) {
            date.disabled = false;
            if (amount) amount.disabled = false;

            if (!date.value) {
                date.value = new Date().toISOString().slice(0,10);
            }
        } else {
            date.value = '';
            date.disabled = true;
            if (amount) amount.disabled = true;
        }
    });
});


document.getElementById('jenisPeserta')?.addEventListener('change', function () {
    const sekolahBox = document.getElementById('filterSekolah');

    if (this.value === 'home_private') {
        sekolahBox.classList.add('hidden');
    } else {
        sekolahBox.classList.remove('hidden');
    }
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/pembayaran/index.blade.php ENDPATH**/ ?>