

<?php $__env->startSection('header'); ?>
<div class="flex items-center gap-4">
    <div class="p-3 rounded-2xl bg-[#8FBFC2]/20">
        <i data-feather="edit-3" class="w-6 h-6 text-[#6FA9AD]"></i>
    </div>
    <div>
        <h1 class="text-xl font-semibold text-gray-800">
            Isi Rapor Peserta
        </h1>
        <p class="text-xs text-gray-500">
            Lengkapi penilaian rapor peserta secara detail
        </p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="bg-white rounded-2xl shadow-sm border mb-8">
    <div class="p-6 grid grid-cols-1 sm:grid-cols-3 gap-6 text-sm">

        
        <div>
            <p class="text-xs text-gray-400 flex items-center gap-1">
                <i data-feather="user" class="w-3 h-3"></i>
                Nama Peserta
            </p>
            <p class="font-semibold text-gray-800">
                <?php echo e($peserta->nama); ?>

            </p>
        </div>

        
        <div>
            <p class="text-xs text-gray-400 flex items-center gap-1">
                <i data-feather="home" class="w-3 h-3"></i>
                Sekolah
            </p>
            <p class="font-semibold text-gray-800">
                <?php echo e($raporTugas->sekolah->nama_sekolah); ?>

            </p>
        </div>

        
        <div>
            <p class="text-xs text-gray-400 flex items-center gap-1">
                <i data-feather="calendar" class="w-3 h-3"></i>
                Semester
            </p>
            <p class="font-semibold text-gray-800">
                <?php echo e($raporTugas->semester->nama_semester); ?>

            </p>
        </div>

    </div>
</div>


<form method="POST"
      action="<?php echo e(route('instruktur.rapor.store', [$raporTugas->id, $peserta->id])); ?>">
    <?php echo csrf_field(); ?>

    <?php echo $__env->make('admin.rapor._form', [
        'rapor'       => $rapor,
        'materis'     => $materis,
        'kompetensis' => $kompetensis,
        'readonly'    => false
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <div class="flex flex-col sm:flex-row justify-end gap-3 mt-8">

        
        <a href="<?php echo e(route('instruktur.rapor-tugas.show', $raporTugas->id)); ?>"
           class="inline-flex items-center justify-center gap-2
                  px-5 py-2.5 rounded-xl
                  border border-gray-300
                  text-sm font-medium text-gray-700
                  hover:bg-gray-50 transition">
            <i data-feather="arrow-left" class="w-4 h-4"></i>
            Kembali
        </a>

        
        <button type="submit"
            class="inline-flex items-center justify-center gap-2
                   px-6 py-2.5 rounded-xl
                   bg-[#8FBFC2] hover:bg-[#6FA9AD]
                   text-white text-sm font-semibold transition">
            <i data-feather="save" class="w-4 h-4"></i>
            Simpan Rapor
        </button>

    </div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ayura\OneDrive\Documents\KP\myrobo_internal\resources\views/instruktur/rapor/form.blade.php ENDPATH**/ ?>